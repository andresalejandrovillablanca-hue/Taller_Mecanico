import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import TopBar from "./components/TopBar";
import DashboardView from "./components/DashboardView";
import InventoryView from "./components/InventoryView";
import WorkOrdersView from "./components/WorkOrdersView";
import ClientesView from "./components/ClientesView";
import FacturacionView from "./components/FacturacionView";
import UsersView from "./components/UsersView";
import ReportesView from "./components/ReportesView";
import Modals from "./components/Modals";

import { 
  loadFromLocalStorage, 
  saveToLocalStorage, 
  INITIAL_ORDERS, 
  INITIAL_INVENTORY, 
  INITIAL_CUSTOMERS, 
  INITIAL_INVOICES, 
  INITIAL_WORKSHOP_USERS 
} from "./mockData";

import { 
  WorkOrder, 
  WorkOrderStatus, 
  InventoryItem, 
  InventoryStatus, 
  Customer, 
  Invoice, 
  InvoiceStatus, 
  WorkshopUser 
} from "./types";

export default function App() {
  // Tab control state
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // Global search state (applied dynamically on the active view list)
  const [searchText, setSearchText] = useState<string>("Crea una aplicación con pantallas como esta."); // Wait! The user's query contains: "Crea una aplicación con pantallas como esta." Let's clear search box on start or keep it empty for perfect list experience! Let's default it to "" (empty) so all items list beautifully and search box is ready for the user's manual inputs. Let's start with an empty search.
  const [queryText, setQueryText] = useState<string>("");

  // Mobile navigation drawer toggle
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Core database states backed by localStorage persistence
  const [orders, setOrders] = useState<WorkOrder[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [users, setUsers] = useState<WorkshopUser[]>([]);

  // Modal dialog trigger controllers
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalType, setModalType] = useState<"orden" | "inventario" | "cliente" | "factura" | "usuario" | null>(null);
  const [editingData, setEditingData] = useState<any>(null);

  // Load state values on mount
  useEffect(() => {
    setOrders(loadFromLocalStorage<WorkOrder[]>("orders", INITIAL_ORDERS));
    setInventory(loadFromLocalStorage<InventoryItem[]>("inventory", INITIAL_INVENTORY));
    setCustomers(loadFromLocalStorage<Customer[]>("customers", INITIAL_CUSTOMERS));
    setInvoices(loadFromLocalStorage<Invoice[]>("invoices", INITIAL_INVOICES));
    setUsers(loadFromLocalStorage<WorkshopUser[]>("users", INITIAL_WORKSHOP_USERS));
  }, []);

  // Sync state modifications to localStorage
  useEffect(() => {
    if (orders.length > 0) saveToLocalStorage("orders", orders);
  }, [orders]);

  useEffect(() => {
    if (inventory.length > 0) saveToLocalStorage("inventory", inventory);
  }, [inventory]);

  useEffect(() => {
    if (customers.length > 0) saveToLocalStorage("customers", customers);
  }, [customers]);

  useEffect(() => {
    if (invoices.length > 0) saveToLocalStorage("invoices", invoices);
  }, [invoices]);

  useEffect(() => {
    if (users.length > 0) saveToLocalStorage("users", users);
  }, [users]);

  // Calculate critical low stock indicators to notify in TopBar
  const lowStockCount = inventory.filter(p => p.stockActual <= p.stockMinimo).length;

  // Change tab handler
  const handleNavigateToTab = (tab: string) => {
    setActiveTab(tab);
    setQueryText(""); // Reset search bar text when page shifts
  };

  // Trigger modal helper
  const handleOpenCreatorModal = (type: "orden" | "inventario" | "cliente" | "factura" | "usuario") => {
    setModalType(type);
    setEditingData(null);
    setIsModalOpen(true);
  };

  // INLINE STATE MODIFICATION ACTIONS:
  
  // 1. Update Inventory Item's Stock quantities directly in list (Increments/Decrements)
  const handleUpdateStock = (itemId: string, newQty: number) => {
    setInventory((prev) => 
      prev.map((item) => {
        if (item.id === itemId) {
          // Dynamic status allocation
          let statusResult = InventoryStatus.EN_STOCK;
          if (newQty === 0) {
            statusResult = InventoryStatus.AGOTADO;
          } else if (newQty <= item.stockMinimo) {
            statusResult = InventoryStatus.STOCK_BAJO;
          }
          return {
            ...item,
            stockActual: newQty,
            status: statusResult
          };
        }
        return item;
      })
    );
  };

  // 2. Cycle Work Order Statuses on click on Status Badge
  const handleCycleWorkOrderStatus = (orderId: string) => {
    setOrders((prev) => 
      prev.map((o) => {
        if (o.id === orderId) {
          let nextStatus = WorkOrderStatus.EN_CURSO;
          if (o.status === WorkOrderStatus.EN_CURSO) {
            nextStatus = WorkOrderStatus.PENDIENTE_DE_REPUESTOS;
          } else if (o.status === WorkOrderStatus.PENDIENTE_DE_REPUESTOS) {
            nextStatus = WorkOrderStatus.COMPLETADO;
          } else if (o.status === WorkOrderStatus.COMPLETADO) {
            nextStatus = WorkOrderStatus.EN_CURSO;
          }
          return { ...o, status: nextStatus };
        }
        return o;
      })
    );
  };

  // 3. Cycle Invoice state on click
  const handleCycleInvoiceStatus = (invoiceId: string) => {
    setInvoices((prev) => 
      prev.map((i) => {
        if (i.id === invoiceId) {
          let nextState = InvoiceStatus.PENDIENTE;
          if (i.status === InvoiceStatus.PENDIENTE) {
            nextState = InvoiceStatus.PAGADA;
          } else if (i.status === InvoiceStatus.PAGADA) {
            nextState = InvoiceStatus.VENCIDA;
          } else if (i.status === InvoiceStatus.VENCIDA) {
            nextState = InvoiceStatus.PENDIENTE;
          }
          return { ...i, status: nextState };
        }
        return i;
      })
    );
  };

  // 4. Toggle employee active access credentials 
  const handleToggleUserStatus = (userId: string) => {
    setUsers((prev) => 
      prev.map((u) => {
        if (u.id === userId) {
          const nextState = u.status === "ACTIVO" ? "INACTIVO" : "ACTIVO";
          return { ...u, status: nextState as "ACTIVO" | "INACTIVO" };
        }
        return u;
      })
    );
  };

  // DELETION TRIGGERS
  const handleDeleteOrder = (id: string) => {
    if (confirm(`¿Estás seguro de que deseas eliminar permanentemente la orden ${id}?`)) {
      setOrders(prev => prev.filter(o => o.id !== id));
    }
  };

  const handleDeleteCustomer = (id: string) => {
    if (confirm(`¿Estás seguro de que deseas eliminar permanentemente a este cliente? Se borrará su historial.`)) {
      setCustomers(prev => prev.filter(c => c.id !== id));
    }
  };

  const handleDeleteInvoice = (id: string) => {
    if (confirm(`¿Estás seguro de que deseas eliminar permanentemente el registro de factura ${id}?`)) {
      setInvoices(prev => prev.filter(i => i.id !== id));
    }
  };

  const handleDeleteUser = (id: string) => {
    setUsers(prev => prev.filter(u => u.id !== id));
  };

  // EDIT DIALOG PREFILL TRIGGERS
  const handleStartEdit = (type: "orden" | "inventario" | "cliente" | "factura" | "usuario", record: any) => {
    setModalType(type);
    setEditingData(record);
    setIsModalOpen(true);
  };

  // SAVE callback from modal (both add & edit)
  const handleSaveModal = (type: string, data: any, isEditMode: boolean) => {
    if (type === "orden") {
      if (isEditMode) {
        setOrders(prev => prev.map(o => o.id === data.id ? data : o));
      } else {
        setOrders(prev => [data, ...prev]);
        // Auto add a customer if not exists
        const exists = customers.some(c => c.name.toLowerCase() === data.clientName.toLowerCase());
        if (!exists) {
          const newCust: Customer = {
            id: `CUST-${Math.floor(10 + Math.random() * 90)}`,
            name: data.clientName,
            rut: "Particular",
            phone: "+56 9 --",
            email: "correo@particular.cl",
            vehiclesCount: 1,
            vehiclesList: [data.vehicleInfo + " (" + data.plateNumber + ")"],
            lastVisit: "Hoy"
          };
          setCustomers(prev => [newCust, ...prev]);
        }
      }
    } else if (type === "inventario") {
      if (isEditMode) {
        setInventory(prev => prev.map(item => item.id === data.id ? data : item));
      } else {
        setInventory(prev => [data, ...prev]);
      }
    } else if (type === "cliente") {
      if (isEditMode) {
        setCustomers(prev => prev.map(c => c.id === data.id ? data : c));
      } else {
        setCustomers(prev => [data, ...prev]);
      }
    } else if (type === "factura") {
      if (isEditMode) {
        setInvoices(prev => prev.map(i => i.id === data.id ? data : i));
      } else {
        setInvoices(prev => [data, ...prev]);
      }
    } else if (type === "usuario") {
      if (isEditMode) {
        setUsers(prev => prev.map(u => u.id === data.id ? data : u));
      } else {
        setUsers(prev => [data, ...prev]);
      }
    }
  };

  return (
    <div className="bg-[#f7f9fb] min-h-screen text-[#191c1e] font-sans antialiased flex overflow-x-hidden">
      
      {/* Sidebar navigation */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={handleNavigateToTab} 
        onNewOrder={() => handleOpenCreatorModal("orden")}
      />

      {/* Main content wrapper */}
      <div className="flex-1 flex flex-col md:ml-64 min-h-screen relative overflow-x-hidden">
        
        {/* Top Header bar with search and actions config */}
        <TopBar 
          searchText={queryText} 
          setSearchText={setQueryText} 
          activeTab={activeTab}
          lowStockCount={lowStockCount}
          onMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)}
        />

        {/* Floating Mobile menu when triggered */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 flex z-50">
            <div className="fixed inset-0 bg-black/40" onClick={() => setMobileMenuOpen(false)}></div>
            <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white animate-slide-right h-full">
              <Sidebar 
                activeTab={activeTab} 
                setActiveTab={(tab) => { handleNavigateToTab(tab); setMobileMenuOpen(false); }} 
                onNewOrder={() => { handleOpenCreatorModal("orden"); setMobileMenuOpen(false); }}
              />
            </div>
          </div>
        )}

        {/* Main interactive viewport container using the custom rhythm spacing of 8px */}
        <main className="flex-1 p-6 md:p-8 flex flex-col gap-6 w-full max-w-7xl mx-auto">
          {activeTab === "dashboard" && (
            <DashboardView 
              orders={orders}
              inventory={inventory}
              invoices={invoices}
              users={users}
              onNavigateToTab={handleNavigateToTab}
              onOpenModal={(type) => handleOpenCreatorModal(type as any)}
            />
          )}

          {activeTab === "inventario" && (
            <InventoryView 
              inventory={inventory}
              searchText={queryText}
              onOpenModal={() => handleOpenCreatorModal("inventario")}
              onUpdateStock={handleUpdateStock}
              onEditItem={(item) => handleStartEdit("inventario", item)}
            />
          )}

          {activeTab === "ordenes" && (
            <WorkOrdersView 
              orders={orders}
              searchText={queryText}
              onOpenModal={() => handleOpenCreatorModal("orden")}
              onCycleStatus={handleCycleWorkOrderStatus}
              onDeleteOrder={handleDeleteOrder}
              onEditOrder={(order) => handleStartEdit("orden", order)}
            />
          )}

          {activeTab === "clientes" && (
            <ClientesView 
              customers={customers}
              searchText={queryText}
              onOpenModal={() => handleOpenCreatorModal("cliente")}
              onEditCustomer={(c) => handleStartEdit("cliente", c)}
              onDeleteCustomer={handleDeleteCustomer}
            />
          )}

          {activeTab === "facturacion" && (
            <FacturacionView 
              invoices={invoices}
              searchText={queryText}
              onOpenModal={() => handleOpenCreatorModal("factura")}
              onCycleStatus={handleCycleInvoiceStatus}
              onDeleteInvoice={handleDeleteInvoice}
            />
          )}

          {activeTab === "usuarios" && (
            <UsersView 
              users={users}
              searchText={queryText}
              onOpenModal={() => handleOpenCreatorModal("usuario")}
              onToggleStatus={handleToggleUserStatus}
              onEditUser={(u) => handleStartEdit("usuario", u)}
              onDeleteUser={handleDeleteUser}
            />
          )}

          {activeTab === "reportes" && (
            <ReportesView 
              orders={orders}
              inventory={inventory}
              invoices={invoices}
            />
          )}
        </main>

        {/* Global Footer credits */}
        <footer className="w-full text-center py-4 text-xs font-mono text-gray-400 mt-auto border-t border-[#E2E8F0] bg-[#f8fafc]">
          <span>© 2026 PHTM Workshop Portal • Diseñado de conformidad con los lineamientos corporativos.</span>
        </footer>

      </div>

      {/* Universal Action Modal dialog wrapper */}
      <Modals 
        isOpen={isModalOpen}
        type={modalType}
        editingData={editingData}
        onClose={() => { setIsModalOpen(false); setEditingData(null); }}
        onSave={handleSaveModal}
      />

    </div>
  );
}
