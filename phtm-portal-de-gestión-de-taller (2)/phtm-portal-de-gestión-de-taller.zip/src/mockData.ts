import { 
  WorkOrder, 
  WorkOrderStatus, 
  InventoryItem, 
  InventoryStatus, 
  Customer, 
  Invoice, 
  InvoiceStatus, 
  WorkshopUser 
} from "./types";

// Initial mock data as defined by reference images
export const INITIAL_ORDERS: WorkOrder[] = [
  {
    id: "WO-2049",
    clientName: "Acme Corp Logistics",
    clientId: "CUST-3",
    vehicleInfo: "2021 Ford Transit 250",
    plateNumber: "XYZ-9876",
    technicianName: "Mike R.",
    status: WorkOrderStatus.EN_CURSO,
    estimatedDelivery: "Oct 24, 14:00",
    createdAt: "hace 10 min",
    notes: "Mantención de kilometraje y cambio de filtros"
  },
  {
    id: "WO-2050",
    clientName: "Robert Evans",
    clientId: "CUST-4",
    vehicleInfo: "2018 Toyota Tacoma",
    plateNumber: "ABC-1234",
    technicianName: "Dave T.",
    status: WorkOrderStatus.PENDIENTE_DE_REPUESTOS,
    estimatedDelivery: "Por definir",
    createdAt: "hace 45 min",
    notes: "Esperando culata de repuesto desde proveedor central"
  },
  {
    id: "WO-2045",
    clientName: "City Delivery Svcs",
    clientId: "CUST-5",
    vehicleInfo: "2022 MB Sprinter",
    plateNumber: "FLEET-04",
    technicianName: "Mike R.",
    status: WorkOrderStatus.EN_CURSO,
    estimatedDelivery: "Oct 24, 17:30",
    createdAt: "hace 2 horas",
    notes: "Frenos delanteros y balanceo"
  },
  {
    id: "WO-2041",
    clientName: "Linda Martinez",
    clientId: "CUST-6",
    vehicleInfo: "2015 Honda CR-V",
    plateNumber: "LND-882",
    technicianName: "Alex G.",
    status: WorkOrderStatus.COMPLETADO,
    estimatedDelivery: "Listo para Retiro",
    createdAt: "hace 7 horas",
    notes: "Cambio de ampolletas y batería"
  },
  {
    id: "WO-8924",
    clientName: "Acme Corp Fleet",
    clientId: "CUST-3",
    vehicleInfo: "2018 Ford Transit",
    plateNumber: "AB-CD-12",
    technicianName: "John Doe",
    status: WorkOrderStatus.EN_CURSO,
    estimatedDelivery: "hace 10 min",
    createdAt: "hace 10 min"
  },
  {
    id: "WO-8923",
    clientName: "Sarah Jenkins",
    clientId: "CUST-7",
    vehicleInfo: "2021 Toyota Camry",
    plateNumber: "XW-99-22",
    technicianName: "Alice Smith",
    status: WorkOrderStatus.COMPLETADO,
    estimatedDelivery: "Listo",
    createdAt: "hace 45 min"
  },
  {
    id: "WO-8922",
    clientName: "City Delivery Svcs",
    clientId: "CUST-5",
    vehicleInfo: "2019 Isuzu NRR",
    plateNumber: "NRR-45-B",
    technicianName: "Robert Brown",
    status: WorkOrderStatus.PENDIENTE_DE_REPUESTOS,
    estimatedDelivery: "Esperando repuestos",
    createdAt: "hace 2 horas"
  }
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    id: "FLT-001-X7",
    sku: "FLT-001-X7",
    name: "Filtro de Aceite Sintético X7",
    category: "Filtros",
    stockActual: 45,
    stockMinimo: 15,
    priceUnit: 12.50,
    status: InventoryStatus.EN_STOCK,
    notes: "Compatible con motores 1.6L a 2.5L"
  },
  {
    id: "BRK-552-B2",
    sku: "BRK-552-B2",
    name: "Pastillas de Freno Delanteras B-20",
    category: "Frenos",
    stockActual: 4,
    stockMinimo: 10,
    priceUnit: 45.00,
    status: InventoryStatus.STOCK_BAJO,
    notes: "Especial para camionetas medianas"
  },
  {
    id: "SUS-990-TR",
    sku: "SUS-990-TR",
    name: "Amortiguador Trasero Reforzado",
    category: "Suspensión",
    stockActual: 12,
    stockMinimo: 4,
    priceUnit: 120.00,
    status: InventoryStatus.EN_STOCK,
    notes: "Servicio pesado todoterreno"
  },
  {
    id: "IGN-102-IX",
    sku: "IGN-102-IX",
    name: "Bujía de Iridio IX",
    category: "Ignición",
    stockActual: 0,
    stockMinimo: 24,
    priceUnit: 8.50,
    status: InventoryStatus.AGOTADO,
    notes: "Alambre ultra fino de 0.6mm"
  },
  {
    id: "LUB-005-30",
    sku: "LUB-005-30",
    name: "Aceite de Motor 5W-30 (5L)",
    category: "Lubricantes",
    stockActual: 28,
    stockMinimo: 10,
    priceUnit: 35.00,
    status: InventoryStatus.EN_STOCK,
    notes: "Sintético full Premium"
  }
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: "CUST-1",
    name: "Juan Pérez",
    rut: "12.345.678-9",
    phone: "+56 9 1234 5678",
    email: "juan.perez@email.com",
    vehiclesCount: 1,
    vehiclesList: ["Toyota Hilux 2021 (AB-CD-12)"],
    lastVisit: "12 Oct, 2023"
  },
  {
    id: "CUST-2",
    name: "María González",
    rut: "18.765.432-1",
    phone: "+56 9 8765 4321",
    email: "mgonzalez@empresa.cl",
    vehiclesCount: 1,
    vehiclesList: ["Ford Ranger 2019 (WX-YZ-98)"],
    lastVisit: "05 Nov, 2023"
  },
  {
    id: "CUST-3",
    name: "Transportes Logísticos SPA",
    rut: "76.543.210-K",
    phone: "+56 2 2345 6789",
    email: "contacto@translog.cl",
    vehiclesCount: 5,
    vehiclesList: [
      "2021 Ford Transit (XYZ-9876)",
      "2018 Ford Transit (AB-CD-12)",
      "Mercedes Sprinter (FLEET-01)",
      "Hyundai H100 (FLEET-02)",
      "Peugeot Partner (FLEET-03)"
    ],
    lastVisit: "18 Nov, 2023"
  },
  {
    id: "CUST-4",
    name: "Robert Evans",
    rut: "15.441.902-8",
    phone: "+56 9 7788 1122",
    email: "robert.evans@gmail.com",
    vehiclesCount: 1,
    vehiclesList: ["2018 Toyota Tacoma (ABC-1234)"],
    lastVisit: "22 Oct, 2023"
  },
  {
    id: "CUST-5",
    name: "City Delivery Svcs",
    rut: "88.332.112-6",
    phone: "+56 2 9988 7766",
    email: "ops@citydelivery.cl",
    vehiclesCount: 3,
    vehiclesList: [
      "2500 Chevy Silverado (FLEET-10)",
      "2019 Isuzu NRR (NRR-45-B)",
      "2022 MB Sprinter (FLEET-04)"
    ],
    lastVisit: "23 Oct, 2023"
  },
  {
    id: "CUST-6",
    name: "Linda Martinez",
    rut: "11.234.567-K",
    phone: "+56 9 3344 5566",
    email: "linda.m@live.cl",
    vehiclesCount: 1,
    vehiclesList: ["2015 Honda CR-V (LND-882)"],
    lastVisit: "24 Oct, 2023"
  },
  {
    id: "CUST-7",
    name: "Sarah Jenkins",
    rut: "16.890.345-2",
    phone: "+56 9 4455 6677",
    email: "sjenkins@outlook.com",
    vehiclesCount: 1,
    vehiclesList: ["2021 Toyota Camry (XW-99-22)"],
    lastVisit: "18 Sep, 2023"
  }
];

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: "FAC-2023-1042",
    clientName: "Transportes del Sur S.A.",
    dateEmitted: "24 Oct 2023",
    amount: 850000,
    status: InvoiceStatus.PAGADA,
    dueDate: "24 Nov 2023"
  },
  {
    id: "FAC-2023-1043",
    clientName: "Logística Martínez EIRL",
    dateEmitted: "22 Oct 2023",
    amount: 1200000,
    status: InvoiceStatus.PENDIENTE,
    dueDate: "22 Nov 2023"
  },
  {
    id: "FAC-2023-1041",
    clientName: "Constructora Andes Spa",
    dateEmitted: "10 Oct 2023",
    amount: 3450000,
    status: InvoiceStatus.VENCIDA,
    dueDate: "10 Nov 2023"
  },
  {
    id: "FAC-2023-1044",
    clientName: "Mecánica Express Ltda",
    dateEmitted: "25 Oct 2023",
    amount: 450000,
    status: InvoiceStatus.PENDIENTE,
    dueDate: "25 Nov 2023"
  }
];

export const INITIAL_WORKSHOP_USERS: WorkshopUser[] = [
  {
    id: "TLL-042",
    name: "Carlos Mendoza",
    role: "Mecánico Jefe",
    email: "carlos.m@phtm.com",
    phone: "+34 600 123 456",
    status: "ACTIVO"
  },
  {
    id: "REC-015",
    name: "Laura Ruiz",
    role: "Recepcionista",
    email: "laura.r@phtm.com",
    phone: "+34 611 987 654",
    status: "ACTIVO"
  },
  {
    id: "TLL-089",
    name: "Diego Gómez",
    role: "Mecánico Especialista",
    email: "diego.g@phtm.com",
    phone: "+34 622 345 678",
    status: "INACTIVO"
  },
  {
    id: "TLL-001",
    name: "John Doe",
    role: "Mecánico Especialista",
    email: "j.doe@phtm.com",
    phone: "+34 656 778 899",
    status: "ACTIVO"
  },
  {
    id: "TLL-002",
    name: "Alice Smith",
    role: "Mecánico Especialista",
    email: "a.smith@phtm.com",
    phone: "+34 656 112 233",
    status: "ACTIVO"
  },
  {
    id: "TLL-003",
    name: "Robert Brown",
    role: "Mecánico Junior",
    email: "r.brown@phtm.com",
    phone: "+34 656 445 566",
    status: "ACTIVO"
  }
];

// Helper functions for persistent data management
export function loadFromLocalStorage<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(`phtm_${key}`);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.warn("localStorage loading failed: ", error);
    return defaultValue;
  }
}

export function saveToLocalStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(`phtm_${key}`, JSON.stringify(data));
  } catch (error) {
    console.warn("localStorage saving failed: ", error);
  }
}
