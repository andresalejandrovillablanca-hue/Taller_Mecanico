import React, { useState, useMemo } from "react";
import { Plus, Download, TrendingUp, AlertTriangle, Coins, Eye, CheckCircle2, SlidersHorizontal, ChevronLeft, ChevronRight, Receipt } from "lucide-react";
import { Invoice, InvoiceStatus } from "../types";

interface FacturacionViewProps {
  invoices: Invoice[];
  searchText: string;
  onOpenModal: () => void;
  onCycleStatus: (invoiceId: string) => void;
  onDeleteInvoice: (invoiceId: string) => void;
}

export default function FacturacionView({
  invoices,
  searchText,
  onOpenModal,
  onCycleStatus,
  onDeleteInvoice
}: FacturacionViewProps) {
  const [selectedStatus, setSelectedStatus] = useState("Todos los Estados");
  const [selectedPeriod, setSelectedPeriod] = useState("Últimos 30 días");

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Real-time aggregates
  const stats = useMemo(() => {
    const totalPaid = invoices
      .filter(i => i.status === InvoiceStatus.PAGADA)
      .reduce((sum, curr) => sum + curr.amount, 0);

    const totalPending = invoices
      .filter(i => i.status === InvoiceStatus.PENDIENTE)
      .reduce((sum, curr) => sum + curr.amount, 0);

    // Filter payments simulated for today
    const receivedToday = invoices
      .filter(i => i.status === InvoiceStatus.PAGADA && (i.id.includes("1042") || i.id.includes("1044")))
      .reduce((sum, curr) => sum + curr.amount, 0);

    return {
      totalPaid,
      totalPending,
      receivedToday: receivedToday || 850000
    };
  }, [invoices]);

  // Filters logic
  const filteredInvoices = useMemo(() => {
    return invoices.filter((i) => {
      // Input title search matched
      const matchesSearch = 
        i.id.toLowerCase().includes(searchText.toLowerCase()) ||
        i.clientName.toLowerCase().includes(searchText.toLowerCase());

      // Dropdown status matched
      let matchesStatus = true;
      if (selectedStatus !== "Todos los Estados") {
        matchesStatus = i.status.toLowerCase() === selectedStatus.toLowerCase();
      }

      return matchesSearch && matchesStatus;
    });
  }, [invoices, searchText, selectedStatus]);

  // Pricing format standard
  const formatMoney = (val: number) => {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
      maximumFractionDigits: 0
    }).format(val || 0);
  };

  // Pagination totals
  const totalPages = Math.max(1, Math.ceil(filteredInvoices.length / itemsPerPage));
  const currentItems = useMemo(() => {
    const startIdx = (currentPage - 1) * itemsPerPage;
    return filteredInvoices.slice(startIdx, startIdx + itemsPerPage);
  }, [filteredInvoices, currentPage]);

  const handlePrevPage = () => setCurrentPage(p => Math.max(1, p - 1));
  const handleNextPage = () => setCurrentPage(p => Math.min(totalPages, p + 1));

  const exportReport = () => {
    const content = invoices.map(i => `${i.id},${i.clientName},${i.dateEmitted},${i.amount},${i.status}`).join("\n");
    const blob = new Blob([`Factura,Cliente,Emisión,Monto,Estado\n` + content], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "PHTM-Historico-Facturacion.csv";
    link.click();
    URL.revokeObjectURL(url);
    alert("Reporte general de facturación y cobros exportado con éxito.");
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto py-2">
      
      {/* Title Header with actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans">Gestión de Facturación</h1>
          <p className="text-sm text-slate-500 mt-1">Resumen de ingresos, control de facturas pendientes de cobro y registros fiscales del taller.</p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto self-stretch sm:self-auto">
          <button 
            onClick={exportReport}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 h-10 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-sm border border-slate-200 rounded-lg shadow-sm transition-colors whitespace-nowrap select-none cursor-pointer"
          >
            <Download size={15} />
            Exportar Reporte
          </button>
          <button 
            onClick={onOpenModal}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 h-10 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg shadow-sm transition-colors whitespace-nowrap select-none cursor-pointer"
          >
            <Plus size={15} className="stroke-[2.5]" />
            Emitir Factura
          </button>
        </div>
      </div>

      {/* Grid of 3 financials cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Stat card 1 */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex justify-between items-start mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">INGRESOS TOTALES (MES)</span>
            <span className="text-blue-600 bg-blue-50 p-1.5 rounded-full"><TrendingUp size={16} /></span>
          </div>
          <div className="text-3xl font-bold text-slate-800">{formatMoney(stats.totalPaid)}</div>
          <p className="text-[11px] text-emerald-600 font-semibold mt-2.5">+12% vs mes anterior</p>
        </div>

        {/* Stat card 2 */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex justify-between items-start mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">FACTURAS PENDIENTES</span>
            <span className="text-rose-605 bg-rose-50 p-1.5 rounded-full"><AlertTriangle size={16} /></span>
          </div>
          <div className="text-3xl font-bold text-rose-700">{formatMoney(stats.totalPending)}</div>
          <p className="text-[11px] text-slate-400 font-medium mt-2.5">Documentos emitidos en seguimiento activo</p>
        </div>

        {/* Stat card 3 */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex justify-between items-start mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">PAGOS RECIBIDOS HOY</span>
            <span className="text-emerald-600 bg-emerald-50 p-1.5 rounded-full"><Coins size={16} /></span>
          </div>
          <div className="text-3xl font-bold text-emerald-700">{formatMoney(stats.receivedToday)}</div>
          <p className="text-[11px] text-slate-400 font-medium mt-2.5">Liquidación diaria de transacciones procesadas</p>
        </div>

      </div>

      {/* Invoices listings main box */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col">
        
        {/* Toolbar selectors */}
        <div className="p-4 border-b border-[#E2E8F0] flex flex-col sm:flex-row gap-3 justify-between items-center bg-slate-50/50">
          <div className="flex gap-2 w-full sm:w-auto">
            <select
              value={selectedStatus}
              onChange={(e) => { setSelectedStatus(e.target.value); setCurrentPage(1); }}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            >
              <option value="Todos los Estados">Todos los Estados</option>
              <option value="Pagada">Pagada</option>
              <option value="Pendiente">Pendiente</option>
              <option value="Vencida">Vencida</option>
            </select>
            
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            >
              <option value="Últimos 30 días">Últimos 30 días</option>
              <option value="Mes actual">Este Mes</option>
              <option value="Año fiscal 2026">Año Fiscal 2026</option>
            </select>
          </div>
          
          <button 
            onClick={() => alert("Puedes filtrar ingresando datos como patentes, marcas, o RUTs directamente en la barra de búsqueda superior.")}
            className="text-xs font-semibold text-slate-400 hover:text-blue-600 flex items-center gap-1.5 cursor-pointer"
          >
            <SlidersHorizontal size={14} />
            Filtros Avanzados
          </button>
        </div>

        {/* Factura Data Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">ID FACTURA</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">CLIENTE</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">FECHA EMISIÓN</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-slate-800">VENCIMIENTO</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-right">MONTO</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">ESTADO</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-right">ACCIONES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm text-slate-800">
              {currentItems.map((i) => (
                <tr key={i.id} className="hover:bg-slate-50/50 transition-colors">
                  
                  {/* ID FACTURA */}
                  <td className="p-4 font-mono text-xs font-bold text-blue-600 align-middle">
                    {i.id}
                  </td>

                  {/* CLIENTE */}
                  <td className="p-4 align-middle">
                    <p className="font-bold text-slate-800 leading-none">{i.clientName}</p>
                    <p className="text-[10px] text-slate-400 mt-1 select-none">Giro Comercial Registrado</p>
                  </td>

                  {/* FECHA EMISIÓN */}
                  <td className="p-4 align-middle font-mono text-xs text-slate-400">
                    {i.dateEmitted}
                  </td>

                  {/* VENCIMIENTO */}
                  <td className="p-4 align-middle font-mono text-xs text-slate-500 font-semibold">
                    {i.dueDate}
                  </td>

                  {/* MONTO */}
                  <td className="p-4 align-middle text-right font-mono font-bold text-slate-800">
                    {formatMoney(i.amount)}
                  </td>

                  {/* ESTADO badge (click cycles) */}
                  <td className="p-4 align-middle">
                    <button
                      onClick={() => onCycleStatus(i.id)}
                      className={`px-3 py-1 rounded-md text-[9px] font-bold uppercase tracking-wider border transition-all hover:scale-95 cursor-pointer ${
                        i.status === InvoiceStatus.PAGADA
                          ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                          : i.status === InvoiceStatus.PENDIENTE
                          ? "bg-amber-50 text-amber-700 border-amber-100"
                          : "bg-rose-50 text-rose-700 border-rose-100"
                      }`}
                      title="Haz clic para cambiar estado fiscal"
                    >
                      {i.status}
                    </button>
                  </td>

                  {/* ACCIONES */}
                  <td className="p-4 align-middle text-right">
                    <div className="flex justify-end gap-1.5">
                      <button 
                        onClick={() => alert(`Visualizando PDF oficial factura: ${i.id}`)}
                        className="text-slate-400 hover:text-blue-600 p-1.5 rounded-lg hover:bg-slate-55 transition-colors cursor-pointer"
                        title="Ver Documento"
                      >
                        <Eye size={15} />
                      </button>
                      <button 
                        onClick={() => onDeleteInvoice(i.id)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50/50 transition-colors cursor-pointer"
                        title="Eliminar Registro"
                      >
                        <AlertTriangle size={15} />
                      </button>
                    </div>
                  </td>

                </tr>
              ))}
              {currentItems.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400 italic">
                    Sin facturas filtradas para los criterios indicados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination bar layout */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/45 flex items-center justify-between text-xs text-slate-400 select-none">
          <span>
            Mostrando {filteredInvoices.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} a {Math.min(currentPage * itemsPerPage, filteredInvoices.length)} de {filteredInvoices.length} facturas registradas
          </span>
          <div className="flex items-center gap-1.5">
            <button 
              onClick={handlePrevPage}
              disabled={currentPage === 1}
              className="p-1 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 disabled:opacity-40 transition-all cursor-pointer"
            >
              <ChevronLeft size={16} />
            </button>
            {Array.from({ length: totalPages }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentPage(idx + 1)}
                className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs font-semibold border cursor-pointer ${
                  currentPage === idx + 1
                    ? "bg-blue-600 text-white border-blue-600"
                    : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                }`}
              >
                {idx + 1}
              </button>
            ))}
            <button 
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className="p-1 rounded-lg bg-white hover:bg-slate-55 border border-slate-200 disabled:opacity-40 transition-all cursor-pointer"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
