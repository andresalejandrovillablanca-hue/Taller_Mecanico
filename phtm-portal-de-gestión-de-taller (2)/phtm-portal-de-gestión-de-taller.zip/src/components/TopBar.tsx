import React, { useState } from "react";
import { Search, Bell, User, Menu, HelpCircle, ShieldAlert } from "lucide-react";

interface TopBarProps {
  searchText: string;
  setSearchText: (text: string) => void;
  activeTab: string;
  onMenuToggle?: () => void;
  lowStockCount: number;
}

export default function TopBar({ 
  searchText, 
  setSearchText, 
  activeTab, 
  onMenuToggle,
  lowStockCount 
}: TopBarProps) {
  const [showNotifications, setShowNotifications] = useState(false);

  // Dynamic placeholders based on active page
  const getSearchPlaceholder = () => {
    switch (activeTab) {
      case "inventario":
        return "Buscar repuestos por nombre, SKU o categoría...";
      case "ordenes":
        return "Buscar órdenes por ID, cliente, patente, técnico...";
      case "clientes":
        return "Buscar clientes por nombre, RUT, patente, contacto...";
      case "facturacion":
        return "Buscar facturas por ID o cliente...";
      case "usuarios":
        return "Buscar usuarios por nombre, ID o email...";
      default:
        return "Buscar órdenes, clientes, repuestos...";
    }
  };

  return (
    <header className="bg-white h-16 w-full border-b border-slate-200 sticky top-0 z-30 flex items-center justify-between px-6 shrink-0">
      {/* Search Input on Left */}
      <div className="flex-1 flex items-center max-w-lg">
        <button 
          onClick={onMenuToggle}
          className="md:hidden text-[#434655] hover:bg-slate-100 p-2 rounded mr-3"
        >
          <Menu size={20} />
        </button>
        <div className="relative w-full">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="global-search-input"
            type="text"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="w-full h-10 pl-10 pr-10 bg-slate-100 border-none rounded-full text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            placeholder={getSearchPlaceholder()}
          />
          {searchText && (
            <button 
              onClick={() => setSearchText("")} 
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 font-bold px-1.5 py-0.5 hover:bg-slate-200 rounded-full"
            >
              clear
            </button>
          )}
        </div>
      </div>

      {/* Action Indicators on Right */}
      <div className="flex items-center gap-4 ml-4 relative">
        {/* Help button */}
        <button 
          onClick={() => alert("Ayuda del Sistema: Para cualquier consulta técnica, contacte al Administrador de Redes.")}
          className="text-slate-400 hover:text-slate-600 hover:bg-slate-50 p-2 rounded-full transition-colors hidden sm:flex items-center justify-center"
          title="Ayuda"
        >
          <HelpCircle size={18} />
        </button>

        {/* Notificaciones Trigger */}
        <div className="relative">
          <button
            id="notifications-bell"
            onClick={() => setShowNotifications(!showNotifications)}
            className="text-slate-400 hover:text-slate-600 hover:bg-slate-50 p-2 rounded-full transition-colors relative cursor-pointer active:scale-95 flex items-center justify-center"
            title="Notificationes"
          >
            <Bell size={18} />
            {lowStockCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white"></span>
            )}
          </button>

          {/* Notifications Dropdown Card */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl border border-slate-200 shadow-lg py-2 z-50 text-sm">
              <div className="px-4 py-2 font-bold border-b border-slate-100 flex justify-between items-center text-slate-800">
                <span>Notificaciones</span>
                <span className="text-[10px] font-mono uppercase bg-rose-50 text-rose-600 px-1.5 py-0.5 rounded-full font-bold">¡Atención!</span>
              </div>
              <div className="max-h-64 overflow-y-auto divide-y divide-slate-100">
                {lowStockCount > 0 ? (
                  <div className="px-4 py-2 hover:bg-slate-50 flex gap-2.5">
                    <ShieldAlert size={18} className="text-rose-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-slate-800 text-xs">Alerta de Inventario Crítico</p>
                      <p className="text-slate-500 text-[11px] mt-0.5">Tienes {lowStockCount} artículos por debajo del stock mínimo. Requieren reposición inmediata.</p>
                    </div>
                  </div>
                ) : null}
                
                <div className="px-4 py-2.5 hover:bg-slate-50">
                  <p className="font-semibold text-slate-800 text-xs">Aprobación de la Orden #WO-2050</p>
                  <p className="text-slate-500 text-[11px] mt-0.5">El cliente Robert Evans está evaluando el presupuesto de repuestos.</p>
                </div>

                <div className="px-4 py-2.5 hover:bg-slate-50">
                  <p className="font-semibold text-slate-800 text-xs">Actualización de Sistema OK</p>
                  <p className="text-slate-500 text-[11px] mt-0.5">Módulo de Facturación Electrónica integrado con SII de manera exitosa.</p>
                </div>
              </div>
              <div className="border-t border-slate-100 px-4 py-1.5 text-center text-[11px] text-blue-600 font-semibold hover:underline cursor-pointer">
                Marcar todas como leídas
              </div>
            </div>
          )}
        </div>

        <div className="h-8 w-[1px] bg-slate-200 mx-1"></div>

        {/* User profile dropdown info layout */}
        <div className="flex items-center gap-2">
          <div className="hidden lg:flex flex-col text-right">
            <span className="text-xs font-bold text-slate-800 leading-none">Andrés Villablanca</span>
            <span className="text-[10px] text-slate-400 mt-1 font-medium">Gerente General</span>
          </div>
          <div className="w-9 h-9 bg-slate-800 text-slate-200 rounded-full flex items-center justify-center border border-slate-200 shadow-sm" title="Andrés Villablanca">
            <span className="text-xs font-bold">AV</span>
          </div>
        </div>
      </div>
    </header>
  );
}
