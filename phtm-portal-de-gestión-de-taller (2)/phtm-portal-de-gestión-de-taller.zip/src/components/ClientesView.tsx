import React, { useState, useMemo } from "react";
import { Plus, Users, UserCheck, Car, HelpCircle, Edit3, Trash2, SlidersHorizontal, ChevronLeft, ChevronRight } from "lucide-react";
import { Customer } from "../types";

interface ClientesViewProps {
  customers: Customer[];
  searchText: string;
  onOpenModal: () => void;
  onEditCustomer: (customer: Customer) => void;
  onDeleteCustomer: (customerId: string) => void;
}

export default function ClientesView({
  customers,
  searchText,
  onOpenModal,
  onEditCustomer,
  onDeleteCustomer
}: ClientesViewProps) {
  const [clientType, setClientType] = useState("Todos");
  const [vehicleBrand, setVehicleBrand] = useState("Todas");

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Extract unique vehicle brands from profiles for dynamic filter dropdowns
  const brandsList = useMemo(() => {
    const list = new Set<string>();
    customers.forEach(c => {
      c.vehiclesList.forEach(v => {
        const brand = v.trim().split(" ")[0] || "";
        if (brand.match(/^[a-zA-Z0-9]+$/)) {
          list.add(brand);
        }
      });
    });
    return ["Todas", ...Array.from(list)];
  }, [customers]);

  // Search logic and selectors matching
  const filteredCustomers = useMemo(() => {
    return customers.filter((c) => {
      // Input text queries
      const matchesSearch = 
        c.name.toLowerCase().includes(searchText.toLowerCase()) ||
        c.rut.toLowerCase().includes(searchText.toLowerCase()) ||
        c.email.toLowerCase().includes(searchText.toLowerCase()) ||
        c.phone.toLowerCase().includes(searchText.toLowerCase()) ||
        c.vehiclesList.some(v => v.toLowerCase().includes(searchText.toLowerCase()));

      // Client categorization (e.g. corporate if lists are larger, standard otherwise)
      let matchesType = true;
      if (clientType === "Corporativo") {
        matchesType = c.vehiclesCount > 2;
      } else if (clientType === "Particular") {
        matchesType = c.vehiclesCount <= 2;
      }

      // Brand matching
      let matchesBrand = true;
      if (vehicleBrand !== "Todas") {
        matchesBrand = c.vehiclesList.some(v => v.toLowerCase().includes(vehicleBrand.toLowerCase()));
      }

      return matchesSearch && matchesType && matchesBrand;
    });
  }, [customers, searchText, clientType, vehicleBrand]);

  // Init avatar bg colors lists helper
  const getAvatarBg = (id: string) => {
    const idx = id.charCodeAt(id.length - 1) % 4;
    return [
      "bg-blue-50 text-blue-600 border border-blue-105", 
      "bg-emerald-50 text-emerald-650 border border-emerald-105", 
      "bg-amber-50 text-amber-600 border border-amber-105", 
      "bg-indigo-50 text-indigo-650 border border-indigo-105"
    ][idx] || "bg-slate-50 text-slate-600 border border-slate-200";
  };

  // Pagination bounds
  const totalPages = Math.max(1, Math.ceil(filteredCustomers.length / itemsPerPage));
  const currentItems = useMemo(() => {
    const startIdx = (currentPage - 1) * itemsPerPage;
    return filteredCustomers.slice(startIdx, startIdx + itemsPerPage);
  }, [filteredCustomers, currentPage]);

  const handlePrevPage = () => setCurrentPage(p => Math.max(1, p - 1));
  const handleNextPage = () => setCurrentPage(p => Math.min(totalPages, p + 1));

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto py-2">
      
      {/* Page Header section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans">Clientes del Taller</h1>
          <p className="text-sm text-slate-500 mt-1">Administra la base de datos de titulares de cuentas corporativas, particulares y flotas asociadas.</p>
        </div>
        <button 
          onClick={onOpenModal}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 h-10 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg shadow-sm transition-colors whitespace-nowrap select-none cursor-pointer"
        >
          <Plus size={15} className="stroke-[2.5]" />
          Nuevo Cliente
        </button>
      </div>

      {/* Summary grids of stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Stat 1 */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">TOTAL DE CLIENTES</span>
            <span className="text-blue-600 bg-blue-50 p-1.5 rounded-full"><Users size={16} /></span>
          </div>
          <div className="text-3xl font-bold text-slate-800">{customers.length}</div>
          <p className="text-[11px] text-emerald-600 font-semibold mt-2.5">+12% vs mes anterior</p>
        </div>

        {/* Stat 2 */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">ACTIVOS ESTE MES</span>
            <span className="text-emerald-650 bg-emerald-50 p-1.5 rounded-full"><UserCheck size={16} /></span>
          </div>
          <div className="text-3xl font-bold text-slate-800">342</div>
          <p className="text-[11px] text-slate-400 font-medium mt-2.5">Han visitado el taller recientemente</p>
        </div>

        {/* Stat 3 */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">NUEVOS VEHÍCULOS</span>
            <span className="text-cyan-600 bg-cyan-50 p-1.5 rounded-full"><Car size={16} /></span>
          </div>
          <div className="text-3xl font-bold text-slate-800">45</div>
          <p className="text-[11px] text-slate-400 font-medium mt-2.5">Patentes ingresadas en últimos 30 días</p>
        </div>

      </div>

      {/* Filter toolbar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row gap-3 justify-between items-center shadow-sm">
        <div className="flex items-center gap-3.5 w-full sm:w-auto">
          <div className="flex flex-col gap-1 w-full sm:w-auto">
            <label className="text-[9px] uppercase font-bold text-slate-400">Tipo de Cliente</label>
            <select
              value={clientType}
              onChange={(e) => { setClientType(e.target.value); setCurrentPage(1); }}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            >
              <option value="Todos">Todos los Tipos</option>
              <option value="Particular">Particular (1-2 Vehículos)</option>
              <option value="Corporativo">Flotas / Corporativos (3+ Vehículos)</option>
            </select>
          </div>

          <div className="flex flex-col gap-1 w-full sm:w-auto">
            <label className="text-[9px] uppercase font-bold text-slate-400">Marca de Vehículo</label>
            <select
              value={vehicleBrand}
              onChange={(e) => { setVehicleBrand(e.target.value); setCurrentPage(1); }}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            >
              {brandsList.map((brand, idx) => (
                <option key={idx} value={brand}>{brand === "Todas" ? "Todas las Marcas" : brand}</option>
              ))}
            </select>
          </div>
        </div>

        <button 
          onClick={() => alert("Puedes filtrar ingresando datos como patentes, marcas, o RUTs directamente en la barra de búsqueda superior.")}
          className="text-xs font-semibold text-slate-400 hover:text-blue-600 flex items-center gap-1.5 cursor-pointer"
        >
          <SlidersHorizontal size={14} />
          Más filtros
        </button>
      </div>

      {/* Main Table layout for Customers */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[750px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">CLIENTE / RUT</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">CONTACTO</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">VEHÍCULO(S) REGISTRADO(S)</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">ÚLTIMA VISITA</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-right">ACCIONES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm text-slate-800">
              {currentItems.map((c) => {
                const initials = c.name.split(" ").map(n => n[0]).join("").slice(0, 2);

                return (
                  <tr key={c.id} className="hover:bg-slate-50/50 transition-colors">
                    
                    {/* User avatar & identity Chilean RUT */}
                    <td className="p-4 align-top">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${getAvatarBg(c.id)} shadow-sm select-none`}>
                          {initials}
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 leading-none">{c.name}</p>
                          <p className="font-mono text-[11px] text-slate-400 mt-1 select-all">RUT: {c.rut}</p>
                        </div>
                      </div>
                    </td>

                    {/* Contact metadata */}
                    <td className="p-4 align-top text-slate-650">
                      <p className="font-semibold text-xs leading-none">{c.phone}</p>
                      <p className="text-slate-400 text-xs mt-1.5 break-all">{c.email}</p>
                    </td>

                    {/* Vehicles tags */}
                    <td className="p-4 align-top">
                      <div className="flex flex-col gap-1.5 max-w-[280px]">
                        {c.vehiclesList.map((vehicle, idx) => {
                          const hasPlate = vehicle.includes("(") && vehicle.includes(")");
                          const name = hasPlate ? vehicle.split("(")[0]?.trim() : vehicle;
                          const plate = hasPlate ? vehicle.split("(")[1]?.replace(")", "")?.trim() : "";

                          return (
                            <div key={idx} className="flex flex-wrap items-center gap-1 bg-slate-50 border border-slate-100 p-1 px-2 rounded-md hover:bg-slate-100 transition-colors font-sans">
                              <span className="text-xs font-bold text-slate-705">{name}</span>
                              {plate && (
                                <span className="font-mono text-[9px] bg-white text-slate-500 border border-slate-200 px-1 py-0.5 rounded-md leading-none uppercase select-all font-bold">
                                  {plate}
                                </span>
                              )}
                            </div>
                          );
                        })}
                        {c.vehiclesCount > c.vehiclesList.length && (
                          <span className="text-[10px] text-blue-600 font-semibold italic">
                            + {c.vehiclesCount - c.vehiclesList.length} vehículos no listados
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Last visit time */}
                    <td className="p-4 align-top font-mono text-xs text-slate-400">
                      {c.lastVisit}
                    </td>

                    {/* Action togglers */}
                    <td className="p-4 align-top text-right">
                      <div className="flex justify-end gap-1.5">
                        <button 
                          onClick={() => onEditCustomer(c)}
                          className="text-slate-400 hover:text-blue-600 p-1.5 rounded-lg hover:bg-slate-55 transition-colors cursor-pointer"
                          title="Editar Cliente"
                        >
                          <Edit3 size={15} />
                        </button>
                        <button 
                          onClick={() => onDeleteCustomer(c.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50/50 transition-colors cursor-pointer"
                          title="Eliminar Cliente"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>

                  </tr>
                );
              })}
              {currentItems.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-400 italic">
                    Sin clientes de taller para los filtros asignados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/45 flex items-center justify-between text-xs text-slate-400 select-none">
          <span>
            Mostrando {filteredCustomers.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} a {Math.min(currentPage * itemsPerPage, filteredCustomers.length)} de {filteredCustomers.length} clientes
          </span>
          <div className="flex items-center gap-1.5">
            <button 
              onClick={handlePrevPage}
              disabled={currentPage === 1}
              className="p-1 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 disabled:opacity-40 transition-all cursor-pointer"
            >
              <ChevronLeft size={16} />
            </button>
            {Array.from({ length: totalPages }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentPage(idx + 1)}
                className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs font-semibold border cursor-pointer ${
                  currentPage === idx + 1
                    ? "bg-blue-600 text-white border-blue-600"
                    : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                }`}
              >
                {idx + 1}
              </button>
            ))}
            <button 
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className="p-1 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 disabled:opacity-40 transition-all cursor-pointer"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
