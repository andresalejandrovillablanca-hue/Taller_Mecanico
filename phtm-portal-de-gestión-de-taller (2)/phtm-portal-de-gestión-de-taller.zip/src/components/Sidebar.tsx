import React from "react";
import { 
  LayoutDashboard, 
  Package, 
  Wrench, 
  Users, 
  Receipt, 
  BarChart3, 
  UserCog, 
  Settings, 
  HelpCircle,
  Plus,
  LogOut
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onNewOrder: () => void;
}

export default function Sidebar({ activeTab, setActiveTab, onNewOrder }: SidebarProps) {
  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "inventario", label: "Inventario", icon: Package },
    { id: "ordenes", label: "Órdenes de Trabajo", icon: Wrench },
    { id: "clientes", label: "Clientes", icon: Users },
    { id: "facturacion", label: "Facturación", icon: Receipt },
    { id: "reportes", label: "Reportes", icon: BarChart3 },
    { id: "usuarios", label: "Gestión de Usuarios", icon: UserCog },
  ];

  return (
    <aside className="bg-slate-900 border-r border-slate-800 h-screen w-64 fixed left-0 top-0 flex flex-col z-40">
      {/* Brand logo header */}
      <div className="h-16 flex items-center px-6 border-b border-slate-800 gap-3 bg-slate-900">
        <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center text-white shadow-md shadow-blue-500/10">
          <Wrench size={16} className="stroke-[2.5]" />
        </div>
        <div className="flex flex-col">
          <span className="font-sans font-bold text-base tracking-tight text-white leading-none">PHTM Portal</span>
          <span className="text-[10px] font-mono tracking-wider text-slate-400 uppercase mt-1">Gerente General</span>
        </div>
      </div>

      {/* Navigation menu */}
      <nav className="flex-grow py-4 px-3 flex flex-col gap-1 overflow-y-auto">
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              id={`nav-item-${item.id}`}
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center px-3 py-2.5 rounded-lg text-left font-sans text-sm font-medium transition-all ${
                isActive
                  ? "bg-blue-600/10 text-blue-400 font-semibold"
                  : "text-slate-400 hover:text-white hover:bg-slate-800"
              }`}
            >
              <IconComponent size={18} className={`mr-3 ${isActive ? "text-blue-400" : "text-slate-400"}`} />
              {item.label}
            </button>
          );
        })}

        <div className="h-[1px] bg-slate-800 my-4 px-3" />

        {/* Secondary Navigation */}
        <button
          id="nav-item-config"
          onClick={() => alert("Configuración de Taller - En desarrollo")}
          className="w-full flex items-center px-3 py-2 text-left font-sans text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all"
        >
          <Settings size={15} className="mr-3 text-slate-500" />
          Configuración
        </button>
        <button
          id="nav-item-soporte"
          onClick={() => alert("Soporte de PHTM - Contacto directo: soporte@phtm.com")}
          className="w-full flex items-center px-3 py-2 text-left font-sans text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all"
        >
          <HelpCircle size={15} className="mr-3 text-slate-500" />
          Soporte
        </button>
      </nav>

      {/* Sidebar Footer with Active User credentials and layout */}
      <div className="p-5 border-t border-slate-800 bg-slate-900 flex flex-col gap-3.5">
        
        {/* Active User Card Profile */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 font-bold border border-slate-700 select-none">
            AV
          </div>
          <div>
            <p className="text-sm font-semibold text-white">Andrés Villablanca</p>
            <p className="text-xs text-slate-400">Gerente General</p>
          </div>
        </div>

        <button
          id="btn-sidebar-new-order"
          onClick={onNewOrder}
          className="w-full bg-blue-600 hover:bg-blue-750 text-white flex items-center justify-center py-2 rounded-lg text-sm font-semibold tracking-wide transition-colors h-10 shadow-lg shadow-blue-500/10 select-none cursor-pointer"
        >
          <Plus size={16} className="mr-1.5 stroke-[3]" />
          Nueva Orden
        </button>
        
        <button
          id="btn-sidebar-logout"
          onClick={() => alert("Cerrando sesión del Portal...")}
          className="w-full hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 flex items-center justify-center py-1.5 rounded-lg text-xs font-medium transition-colors"
        >
          <LogOut size={13} className="mr-1.5" />
          Cerrar Sesión
        </button>
      </div>
    </aside>
  );
}
