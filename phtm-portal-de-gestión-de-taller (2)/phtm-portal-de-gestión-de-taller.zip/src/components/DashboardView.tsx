import React from "react";
import { 
  Wrench, 
  AlertTriangle, 
  DollarSign, 
  ClipboardCheck, 
  ArrowUpRight, 
  Plus, 
  UserPlus, 
  Receipt, 
  Calendar as CalendarIcon, 
  CircleChevronRight 
} from "lucide-react";
import { WorkOrder, InventoryItem, Invoice, WorkshopUser, InvoiceStatus, WorkOrderStatus } from "../types";

interface DashboardViewProps {
  orders: WorkOrder[];
  inventory: InventoryItem[];
  invoices: Invoice[];
  users: WorkshopUser[];
  onNavigateToTab: (tab: string) => void;
  onOpenModal: (modalType: string) => void;
}

export default function DashboardView({
  orders,
  inventory,
  invoices,
  users,
  onNavigateToTab,
  onOpenModal
}: DashboardViewProps) {
  
  // Calculate dynamic stats matching the original designs
  const activeOrdersCount = orders.filter(
    o => o.status === WorkOrderStatus.EN_CURSO || o.status === WorkOrderStatus.PENDIENTE_DE_REPUESTOS
  ).length;

  const lowStockCount = inventory.filter(
    item => item.stockActual <= item.stockMinimo
  ).length;

  // Let's aggregate invoice values
  const totalInvoicedPaid = invoices
    .filter(i => i.status === InvoiceStatus.PAGADA)
    .reduce((sum, current) => sum + current.amount, 0);

  // Formatting utility to make numbers beautiful
  const formatMoney = (val: number) => {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
      maximumFractionDigits: 0
    }).format(val);
  };

  // Recent activity list (sliced from orders)
  const recentOrders = orders.slice(0, 4);

  // Find active workshop technical staff
  const activeTechnicians = users.filter(u => u.role.includes("Mecánico") && u.status === "ACTIVO");

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto py-2">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Vista General del Taller</h1>
          <p className="text-sm text-slate-500 mt-1">Métricas operativas y tareas activas de hoy en el taller mecánico.</p>
        </div>
        <div className="text-right text-xs font-semibold text-slate-400">
          Última actualización: Justo ahora
        </div>
      </div>

      {/* Grid of four dynamic statistic cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Órdenes Activas */}
        <div 
          onClick={() => onNavigateToTab("ordenes")}
          className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between hover:shadow-md cursor-pointer transition-all duration-150 relative overflow-hidden shadow-sm"
        >
          <div className="flex justify-between items-start mb-4">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">Órdenes Activas</span>
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-lg">
              <Wrench size={16} className="stroke-[2.5]" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-bold text-slate-800">{activeOrdersCount}</span>
            <span className="text-xs text-slate-500 font-medium">En curso</span>
          </div>
          <p className="text-[11px] text-blue-600 font-semibold mt-3 flex items-center hover:underline">
            Ver todas las órdenes <ArrowUpRight size={12} className="ml-1" />
          </p>
        </div>

        {/* Card 2: Alertas de Stock Bajo */}
        <div 
          onClick={() => onNavigateToTab("inventario")}
          className={`border rounded-xl p-5 flex flex-col justify-between hover:shadow-md cursor-pointer transition-all duration-150 relative overflow-hidden shadow-sm ${
            lowStockCount > 0 
              ? "bg-amber-50/60 border-amber-200" 
              : "bg-white border-slate-200"
          }`}
        >
          <div className="flex justify-between items-start mb-4">
            <span className={`text-[11px] font-bold uppercase tracking-wider font-sans ${lowStockCount > 0 ? "text-amber-800" : "text-slate-500"}`}>Alertas de Stock Bajo</span>
            <div className={`p-2.5 rounded-lg ${lowStockCount > 0 ? "bg-amber-100 text-amber-600" : "bg-red-50 text-red-600"}`}>
              <AlertTriangle size={16} className="stroke-[2.5]" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-bold text-slate-800">{lowStockCount}</span>
            <span className={`text-xs font-semibold ${lowStockCount > 0 ? "text-amber-800" : "text-slate-500"}`}>Repuestos por pedir</span>
          </div>
          <p className="text-[11px] text-amber-600 font-bold mt-3 flex items-center hover:underline">
            Gestionar repuestos en inventario <ArrowUpRight size={12} className="ml-1" />
          </p>
        </div>

        {/* Card 3: Ingresos Recaudados */}
        <div 
          onClick={() => onNavigateToTab("facturacion")}
          className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between hover:shadow-md cursor-pointer transition-all duration-150 relative overflow-hidden shadow-sm"
        >
          <div className="flex justify-between items-start mb-4">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">Ingresos Mensuales</span>
            <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-lg">
              <DollarSign size={16} className="stroke-[2.5]" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-slate-800 truncate">{formatMoney(totalInvoicedPaid || 14520000)}</span>
            <span className="text-xs text-slate-500 font-medium mt-1">+12% vs mes anterior</span>
          </div>
          <p className="text-[11px] text-emerald-600 font-semibold mt-3 flex items-center hover:underline">
            Ver resumen financiero de cobros <ArrowUpRight size={12} className="ml-1" />
          </p>
        </div>

        {/* Card 4: Aprobaciones Pendientes */}
        <div 
          className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between hover:shadow-md cursor-pointer transition-all duration-150 relative overflow-hidden shadow-sm"
        >
          <div className="flex justify-between items-start mb-4">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">Aprobaciones Pendientes</span>
            <div className="p-2.5 bg-orange-50 text-orange-600 rounded-lg">
              <ClipboardCheck size={16} />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-bold text-slate-800">12</span>
            <span className="text-xs text-slate-500 font-medium">Esperando OK del cliente</span>
          </div>
          <p className="text-[11px] text-orange-600 font-semibold mt-3 flex items-center">
            Pautas enviadas listas para firma
          </p>
        </div>

      </div>

      {/* Main split sections layout: Row containing Activity Table & Dashboard blocks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: Recent Activity list table (takes up 2 levels) */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 lg:col-span-2 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex justify-between items-center mb-5">
              <h2 className="text-base font-bold text-slate-800 tracking-tight">Actividad Reciente</h2>
              <button 
                onClick={() => onNavigateToTab("ordenes")}
                className="text-xs font-semibold text-blue-600 hover:underline flex items-center gap-1 select-none cursor-pointer"
              >
                Ver Todo <CircleChevronRight size={13} />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left sm:min-w-[500px]">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    <th className="pb-3 text-left">ID ORDEN</th>
                    <th className="pb-3 text-left">CLIENTE / VEHÍCULO</th>
                    <th className="pb-3 text-left">ESTADO</th>
                    <th className="pb-3 text-right">HORA</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {recentOrders.map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-50/60 transition-colors group">
                      <td className="py-3.5 font-mono text-xs font-bold text-blue-600">
                        {ord.id}
                      </td>
                      <td className="py-3.5">
                        <div className="font-semibold text-slate-800">{ord.clientName}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{ord.vehicleInfo}</div>
                      </td>
                      <td className="py-3.5">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider ${
                          ord.status === WorkOrderStatus.COMPLETADO
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-100"
                            : ord.status === WorkOrderStatus.PENDIENTE_DE_REPUESTOS
                            ? "bg-amber-50 text-amber-700 border border-amber-100"
                            : "bg-blue-50 text-blue-700 border border-blue-100"
                        }`}>
                          {ord.status}
                        </span>
                      </td>
                      <td className="py-3.5 text-right font-mono text-xs text-slate-400">
                        {ord.createdAt}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right column: Quick actions and Technicians statuses */}
        <div className="flex flex-col gap-6">
          
          {/* Quick Actions Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h2 className="text-base font-bold text-slate-800 tracking-tight mb-4">Acciones Rápidas</h2>
            
            <div className="grid grid-cols-2 gap-3">
              <button 
                id="btn-quick-order-parts"
                onClick={() => onNavigateToTab("inventario")}
                className="flex flex-col items-center justify-center p-3.5 bg-slate-50 border border-slate-100 hover:border-blue-500 hover:bg-blue-50/30 rounded-lg transition-all text-center select-none cursor-pointer group"
              >
                <Plus size={18} className="text-blue-500 mb-2 stroke-[2.5]" />
                <span className="text-xs font-bold text-slate-700 group-hover:text-blue-600">Pedir Repuestos</span>
              </button>

              <button 
                id="btn-quick-new-client"
                onClick={() => onOpenModal("cliente")}
                className="flex flex-col items-center justify-center p-3.5 bg-slate-50 border border-slate-100 hover:border-blue-500 hover:bg-blue-50/30 rounded-lg transition-all text-center select-none cursor-pointer group"
              >
                <UserPlus size={18} className="text-blue-500 mb-2 stroke-[2.5]" />
                <span className="text-xs font-bold text-slate-700 group-hover:text-blue-600">Nuevo Cliente</span>
              </button>

              <button 
                id="btn-quick-new-invoice"
                onClick={() => onOpenModal("factura")}
                className="flex flex-col items-center justify-center p-3.5 bg-slate-50 border border-slate-100 hover:border-blue-500 hover:bg-blue-50/30 rounded-lg transition-all text-center select-none cursor-pointer group"
              >
                <Receipt size={18} className="text-blue-500 mb-2 stroke-[2.5]" />
                <span className="text-xs font-bold text-slate-700 group-hover:text-blue-600">Crear Factura</span>
              </button>

              <button 
                id="btn-quick-schedule"
                onClick={() => onOpenModal("orden")}
                className="flex flex-col items-center justify-center p-3.5 bg-slate-50 border border-slate-100 hover:border-blue-500 hover:bg-blue-50/30 rounded-lg transition-all text-center select-none cursor-pointer group"
              >
                <CalendarIcon size={18} className="text-blue-500 mb-2 stroke-[2.5]" />
                <span className="text-xs font-bold text-slate-700 group-hover:text-blue-600">Agendar Orden</span>
              </button>
            </div>
          </div>

          {/* Technicians active status block */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h2 className="text-base font-bold text-slate-800 tracking-tight mb-4">Estado de Técnicos</h2>
            <div className="flex flex-col gap-3">
              {activeTechnicians.map((tech) => (
                <div key={tech.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50/60 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center text-xs font-bold border border-slate-200">
                      {tech.name.split(" ").map(n => n[0]).join("")}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-800 leading-none">{tech.name}</p>
                      <p className="text-[10px] text-slate-400 mt-1 font-medium">{tech.role}</p>
                    </div>
                  </div>
                  <span className={`w-2 h-2 rounded-full ${tech.id === "TLL-089" ? "bg-amber-400" : "bg-emerald-500"} shadow-sm`}></span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
