import React, { useState, useMemo } from "react";
import { 
  Plus, 
  Wrench, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  SlidersHorizontal, 
  MoreVertical,
  ChevronLeft,
  ChevronRight,
  Eye,
  Trash2,
  RefreshCw
} from "lucide-react";
import { WorkOrder, WorkOrderStatus } from "../types";

interface WorkOrdersViewProps {
  orders: WorkOrder[];
  searchText: string;
  onOpenModal: () => void;
  onCycleStatus: (orderId: string) => void;
  onDeleteOrder: (orderId: string) => void;
  onEditOrder: (order: WorkOrder) => void;
}

export default function WorkOrdersView({
  orders,
  searchText,
  onOpenModal,
  onCycleStatus,
  onDeleteOrder,
  onEditOrder
}: WorkOrdersViewProps) {
  // Checkbox filters
  const [filterEnCurso, setFilterEnCurso] = useState(true);
  const [filterPendiente, setFilterPendiente] = useState(true);
  const [filterCompletado, setFilterCompletado] = useState(false);
  const [selectedTechnician, setSelectedTechnician] = useState("Todos los Técnicos");

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Aggregate stats from orders
  const stats = useMemo(() => {
    return {
      active: orders.filter(o => o.status !== WorkOrderStatus.COMPLETADO).length,
      inProgress: orders.filter(o => o.status === WorkOrderStatus.EN_CURSO).length,
      pending: orders.filter(o => o.status === WorkOrderStatus.PENDIENTE_DE_REPUESTOS).length,
      completedToday: orders.filter(o => o.status === WorkOrderStatus.COMPLETADO).length,
    };
  }, [orders]);

  // Aggregate list of actual technicians in orders
  const techniciansList = useMemo(() => {
    const list = new Set(orders.map(o => o.technicianName).filter(Boolean));
    return ["Todos los Técnicos", ...Array.from(list)];
  }, [orders]);

  // Filter criteria logic
  const filteredOrders = useMemo(() => {
    return orders.filter((o) => {
      // Search Box queries
      const matchesSearch = 
        o.id.toLowerCase().includes(searchText.toLowerCase()) ||
        o.clientName.toLowerCase().includes(searchText.toLowerCase()) ||
        o.vehicleInfo.toLowerCase().includes(searchText.toLowerCase()) ||
        o.plateNumber.toLowerCase().includes(searchText.toLowerCase()) ||
        o.technicianName.toLowerCase().includes(searchText.toLowerCase());

      // Technician Selection
      const matchesTech = 
        selectedTechnician === "Todos los Técnicos" || 
        o.technicianName === selectedTechnician;

      // Checkbox status matches
      let matchesStatusCheckbox = false;
      if (o.status === WorkOrderStatus.EN_CURSO && filterEnCurso) matchesStatusCheckbox = true;
      if (o.status === WorkOrderStatus.PENDIENTE_DE_REPUESTOS && filterPendiente) matchesStatusCheckbox = true;
      if (o.status === WorkOrderStatus.COMPLETADO && filterCompletado) matchesStatusCheckbox = true;

      return matchesSearch && matchesTech && matchesStatusCheckbox;
    });
  }, [orders, searchText, filterEnCurso, filterPendiente, filterCompletado, selectedTechnician]);

  // Pagination logic
  const totalPages = Math.max(1, Math.ceil(filteredOrders.length / itemsPerPage));
  const currentItems = useMemo(() => {
    const startIdx = (currentPage - 1) * itemsPerPage;
    return filteredOrders.slice(startIdx, startIdx + itemsPerPage);
  }, [filteredOrders, currentPage]);

  const handlePrevPage = () => setCurrentPage(p => Math.max(1, p - 1));
  const handleNextPage = () => setCurrentPage(p => Math.min(totalPages, p + 1));

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto py-2">
      
      {/* Title Header with actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans">Órdenes de Trabajo</h1>
          <p className="text-sm text-slate-500 mt-1">Administra, asigna y sigue reparaciones activas y trabajos de servicio del taller.</p>
        </div>
        <button 
          onClick={onOpenModal}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 h-10 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg shadow-sm transition-colors whitespace-nowrap select-none cursor-pointer"
        >
          <Plus size={15} className="stroke-[2.5]" />
          Nueva Orden
        </button>
      </div>

      {/* Grid of job totals stats blocks */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Stat Block 1 */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">TOTAL ACTIVAS</span>
            <span className="text-blue-605 bg-blue-50/60 p-1 rounded-full"><Wrench size={13} /></span>
          </div>
          <span className="text-2xl font-bold text-slate-800">{stats.active}</span>
        </div>

        {/* Stat Block 2 */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">EN CURSO</span>
            <span className="text-amber-605 bg-amber-50/60 p-1 rounded-full"><Clock size={13} /></span>
          </div>
          <span className="text-2xl font-bold text-slate-800">{stats.inProgress}</span>
        </div>

        {/* Stat Block 3 */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">PENDIENTE REPUESTOS</span>
            <span className="text-rose-605 bg-rose-50/60 p-1 rounded-full"><AlertTriangle size={13} /></span>
          </div>
          <span className="text-2xl font-bold text-slate-800">{stats.pending}</span>
        </div>

        {/* Stat Block 4 */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">COMPLETADAS HOY</span>
            <span className="text-emerald-600 bg-emerald-50 p-1 rounded-full"><CheckCircle2 size={13} /></span>
          </div>
          <span className="text-2xl font-bold text-slate-800">{stats.completedToday}</span>
        </div>

      </div>

      {/* Filter checkboxes bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-slate-100 justify-between gap-4 shadow-sm">
        
        {/* State Checkbox filters */}
        <div className="flex items-center gap-5 flex-wrap flex-grow pb-2 md:pb-0">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">FILTRAR POR ESTADO:</span>
          
          <label className="flex items-center gap-2 cursor-pointer font-sans text-sm font-semibold text-slate-700 hover:text-slate-900 transition-colors">
            <input 
              type="checkbox"
              checked={filterEnCurso}
              onChange={(e) => { setFilterEnCurso(e.target.checked); setCurrentPage(1); }}
              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-offset-0"
            />
            En Curso
          </label>

          <label className="flex items-center gap-2 cursor-pointer font-sans text-sm font-semibold text-slate-700 hover:text-slate-900 transition-colors">
            <input 
              type="checkbox"
              checked={filterPendiente}
              onChange={(e) => { setFilterPendiente(e.target.checked); setCurrentPage(1); }}
              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-offset-0"
            />
            Pendiente de Repuestos
          </label>

          <label className="flex items-center gap-2 cursor-pointer font-sans text-sm font-semibold text-slate-700 hover:text-slate-900 transition-colors">
            <input 
              type="checkbox"
              checked={filterCompletado}
              onChange={(e) => { setFilterCompletado(e.target.checked); setCurrentPage(1); }}
              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-offset-0"
            />
            Completado
          </label>
        </div>

        {/* Tech select filter */}
        <div className="flex items-center gap-3 pt-3 md:pt-0 pl-0 md:pl-5 flex-shrink-0">
          <SlidersHorizontal size={15} className="text-slate-400" />
          <select 
            value={selectedTechnician}
            onChange={(e) => { setSelectedTechnician(e.target.value); setCurrentPage(1); }}
            className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          >
            {techniciansList.map((tech, idx) => (
              <option key={idx} value={tech}>{tech}</option>
            ))}
          </select>
        </div>

      </div>

      {/* Orders main listings table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[750px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">ID OT</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Cliente</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Vehículo / Patente</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Técnico</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Estado (Clic para Cambiar)</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-slate-800">Entrega Est.</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm text-slate-800">
              {currentItems.map((ord) => (
                <tr key={ord.id} className="hover:bg-slate-50/50 transition-all">
                  
                  {/* ID OT */}
                  <td className="p-4 font-mono text-xs font-bold text-blue-600 align-middle">
                    {ord.id}
                  </td>
                  
                  {/* Client */}
                  <td className="p-4 align-middle">
                    <p className="font-bold text-slate-800 leading-none">{ord.clientName}</p>
                    <p className="text-[11px] text-slate-400 mt-1">Titular de la Orden</p>
                  </td>

                  {/* Vehicle plate details */}
                  <td className="p-4 align-middle">
                    <p className="font-semibold text-slate-800">{ord.vehicleInfo}</p>
                    <span className="inline-block mt-1 font-mono text-[9px] font-bold bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-md leading-none select-all uppercase border border-slate-200">
                      {ord.plateNumber}
                    </span>
                  </td>

                  {/* Tech assigned */}
                  <td className="p-4 align-middle font-semibold text-slate-550">
                    {ord.technicianName}
                  </td>

                  {/* Status click cycles */}
                  <td className="p-4 align-middle">
                    <button
                      onClick={() => onCycleStatus(ord.id)}
                      className={`px-3 py-1 rounded-md text-[9px] font-bold uppercase tracking-wider border transition-all hover:scale-95 cursor-pointer ${
                        ord.status === WorkOrderStatus.COMPLETADO
                          ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                          : ord.status === WorkOrderStatus.PENDIENTE_DE_REPUESTOS
                          ? "bg-amber-50 text-amber-700 border-amber-100"
                          : "bg-blue-50 text-blue-700 border-blue-100"
                      }`}
                      title="Haz clic para alternar el estado"
                    >
                      {ord.status}
                    </button>
                    {ord.notes && (
                      <p className="text-[10px] text-slate-400 italic mt-1 font-mono truncate max-w-[150px]">{ord.notes}</p>
                    )}
                  </td>

                  {/* Delivery date estimate info */}
                  <td className="p-4 align-middle font-mono font-semibold text-xs text-slate-500">
                    {ord.estimatedDelivery}
                  </td>

                  {/* Action buttons */}
                  <td className="p-4 align-middle text-right">
                    <div className="flex justify-end gap-1.5">
                      <button 
                        onClick={() => onEditOrder(ord)}
                        className="text-slate-400 hover:text-blue-600 p-1.5 rounded-lg hover:bg-slate-55 transition-colors cursor-pointer"
                        title="Editar Orden de Trabajo"
                      >
                        <Eye size={15} />
                      </button>
                      <button 
                        onClick={() => onDeleteOrder(ord.id)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50/50 transition-colors cursor-pointer"
                        title="Eliminar Orden"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>

                </tr>
              ))}
              {currentItems.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400 italic font-sans pb-10">
                    Sin resultados bajo las directivas indicadas.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Dynamic Pagination footer matching image spec */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/45 flex items-center justify-between text-xs text-slate-400 select-none">
          <span>
            Mostrando {filteredOrders.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} a {Math.min(currentPage * itemsPerPage, filteredOrders.length)} de {filteredOrders.length} resultados
          </span>
          <div className="flex items-center gap-1.5">
            <button 
              onClick={handlePrevPage}
              disabled={currentPage === 1}
              className="p-1 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 disabled:opacity-40 transition-all cursor-pointer"
            >
              <ChevronLeft size={16} />
            </button>
            {Array.from({ length: totalPages }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentPage(idx + 1)}
                className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs font-semibold border cursor-pointer ${
                  currentPage === idx + 1
                    ? "bg-blue-600 text-white border-blue-600"
                    : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                }`}
              >
                {idx + 1}
              </button>
            ))}
            <button 
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className="p-1 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 disabled:opacity-40 transition-all cursor-pointer"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
