import React, { useState, useEffect } from "react";
import { X, Save } from "lucide-react";
import { 
  WorkOrder, 
  WorkOrderStatus, 
  InventoryItem, 
  InventoryStatus, 
  Invoice, 
  InvoiceStatus, 
  WorkshopUser 
} from "../types";

interface ModalsProps {
  isOpen: boolean;
  type: "orden" | "inventario" | "cliente" | "factura" | "usuario" | null;
  editingData: any; // If editing a record, this will be populated
  onClose: () => void;
  onSave: (type: string, data: any, isEdit: boolean) => void;
}

export default function Modals({
  isOpen,
  type,
  editingData,
  onClose,
  onSave
}: ModalsProps) {
  
  // Local state for all fields
  const [formFields, setFormFields] = useState<any>({});

  // Reset/populate fields when modal details shift
  useEffect(() => {
    if (!isOpen) {
      setFormFields({});
      return;
    }

    if (editingData) {
      setFormFields({ ...editingData });
    } else {
      // Default baseline values for creation
      if (type === "orden") {
        setFormFields({
          id: `WO-${Math.floor(1000 + Math.random() * 9000)}`,
          clientName: "",
          clientId: "CUST-3",
          vehicleInfo: "",
          plateNumber: "",
          technicianName: "John Doe",
          status: WorkOrderStatus.EN_CURSO,
          estimatedDelivery: "Oct 24, 17:00",
          createdAt: "Justo ahora"
        });
      } else if (type === "inventario") {
        setFormFields({
          id: `SKU-${Math.floor(100 + Math.random() * 900)}-X`,
          sku: `SKU-${Math.floor(100 + Math.random() * 900)}-X`,
          name: "",
          category: "Filtros",
          stockActual: 10,
          stockMinimo: 5,
          priceUnit: 15000,
          status: InventoryStatus.EN_STOCK
        });
      } else if (type === "cliente") {
        setFormFields({
          id: `CUST-${Math.floor(10 + Math.random() * 90)}`,
          name: "",
          rut: "",
          phone: "+56 9 ",
          email: "",
          vehiclesCount: 1,
          vehiclesList: [],
          lastVisit: "Hoy"
        });
      } else if (type === "factura") {
        setFormFields({
          id: `FAC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          clientName: "",
          dateEmitted: "21 Jun 2026",
          dueDate: "21 Jul 2026",
          amount: 150000,
          status: InvoiceStatus.PENDIENTE
        });
      } else if (type === "usuario") {
        setFormFields({
          id: `TLL-${Math.floor(100 + Math.random() * 900)}`,
          name: "",
          role: "Mecánico Especialista",
          email: "",
          phone: "+56 9 ",
          status: "ACTIVO"
        });
      }
    }
  }, [isOpen, type, editingData]);

  if (!isOpen) return null;

  const isEdit = !!editingData;

  const handleInputChange = (field: string, val: any) => {
    setFormFields((prev: any) => ({ ...prev, [field]: val }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(type!, formFields, isEdit);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 overflow-y-auto flex items-center justify-center p-4 z-50 backdrop-blur-xs">
      <div className="bg-white rounded-xl border border-slate-200 max-w-lg w-full shadow-lg overflow-hidden flex flex-col">
        
        {/* Modal Header */}
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-base font-bold text-slate-800 font-sans">
            {isEdit ? "Editar" : "Crear / Añadir"}{" "}
            {type === "orden" && "Orden de Trabajo"}
            {type === "inventario" && "Insumo de Inventario"}
            {type === "cliente" && "Perfil de Cliente"}
            {type === "factura" && "Factura Tributaria"}
            {type === "usuario" && "Ficha de Empleado"}
          </h3>
          <button 
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-650 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Modal Body Container with persistent labels above files */}
        <form onSubmit={handleSubmit} className="p-6 flex flex-col gap-4 font-sans max-h-[75vh] overflow-y-auto">
          
          {/* Form Type 1: ORDEN DE TRABAJO */}
          {type === "orden" && (
            <>
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">ID ORDEN (Generado)</label>
                <input 
                  type="text" 
                  disabled 
                  value={formFields.id || ""}
                  className="h-10 px-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-400 outline-none cursor-not-allowed font-mono"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Nombre de Cliente *</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej. Juan Pérez"
                  value={formFields.clientName || ""}
                  onChange={(e) => handleInputChange("clientName", e.target.value)}
                  className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Modelo de Vehículo *</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Ej. Toyota Hilux 2021"
                    value={formFields.vehicleInfo || ""}
                    onChange={(e) => handleInputChange("vehicleInfo", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Patente / Matrícula *</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Ej. AB-CD-12"
                    value={formFields.plateNumber || ""}
                    onChange={(e) => handleInputChange("plateNumber", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono uppercase"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Técnico Asignado</label>
                  <select
                    value={formFields.technicianName || "John Doe"}
                    onChange={(e) => handleInputChange("technicianName", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  >
                    <option value="John Doe">John Doe</option>
                    <option value="Alice Smith">Alice Smith</option>
                    <option value="Robert Brown">Robert Brown</option>
                    <option value="Mike R.">Mike R.</option>
                    <option value="Dave T.">Dave T.</option>
                    <option value="Alex G.">Alex G.</option>
                  </select>
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-sans">Estado del Trabajo</label>
                  <select
                    value={formFields.status || WorkOrderStatus.EN_CURSO}
                    onChange={(e) => handleInputChange("status", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  >
                    <option value={WorkOrderStatus.EN_CURSO}>EN CURSO</option>
                    <option value={WorkOrderStatus.PENDIENTE_DE_REPUESTOS}>PENDIENTE DE REPUESTOS</option>
                    <option value={WorkOrderStatus.COMPLETADO}>COMPLETADO</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Entrega Estimada</label>
                <input 
                  type="text" 
                  placeholder="Ej. Oct 24, 18:00 o Por definir"
                  value={formFields.estimatedDelivery || ""}
                  onChange={(e) => handleInputChange("estimatedDelivery", e.target.value)}
                  className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Observaciones Técnicas / Notas</label>
                <textarea 
                  rows={2}
                  placeholder="Detalles sobre averías mecánicas..."
                  value={formFields.notes || ""}
                  onChange={(e) => handleInputChange("notes", e.target.value)}
                  className="p-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all resize-none"
                />
              </div>
            </>
          )}

          {/* Form Type 2: INVENTARIO */}
          {type === "inventario" && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">SKU de Fábrica *</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Ej. FLT-001-X7"
                    value={formFields.sku || ""}
                    onChange={(e) => {
                      handleInputChange("sku", e.target.value);
                      handleInputChange("id", e.target.value);
                    }}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono uppercase"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-sans">Categoría</label>
                  <select
                    value={formFields.category || "Filtros"}
                    onChange={(e) => handleInputChange("category", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all font-sans"
                  >
                    <option value="Filtros">Filtros</option>
                    <option value="Frenos">Frenos</option>
                    <option value="Suspensión">Suspensión</option>
                    <option value="Lubricantes">Lubricantes</option>
                    <option value="Ignición">Ignición</option>
                    <option value="Accesorios">Accesorios</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Nombre del Repuesto *</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej. Pastillas de Freno B-20"
                  value={formFields.name || ""}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Stock Inicial Real *</label>
                  <input 
                    type="number" 
                    required
                    min={0}
                    value={formFields.stockActual === undefined ? 10 : formFields.stockActual}
                    onChange={(e) => handleInputChange("stockActual", parseInt(e.target.value, 10) || 0)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Límite de Stock Mínimo *</label>
                  <input 
                    type="number" 
                    required
                    min={1}
                    value={formFields.stockMinimo === undefined ? 5 : formFields.stockMinimo}
                    onChange={(e) => handleInputChange("stockMinimo", parseInt(e.target.value, 10) || 1)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Precio Unitario ($ CLP) *</label>
                <input 
                  type="number" 
                  required
                  min={1}
                  placeholder="Monto en Pesos de adquisición por unidad"
                  value={formFields.priceUnit || ""}
                  onChange={(e) => handleInputChange("priceUnit", parseFloat(e.target.value) || 0)}
                  className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Notas del Fabricante / EAN</label>
                <textarea 
                  rows={2}
                  placeholder="Ej. Compatible con motores Ford, etc."
                  value={formFields.notes || ""}
                  onChange={(e) => handleInputChange("notes", e.target.value)}
                  className="p-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all resize-none"
                />
              </div>
            </>
          )}

          {/* Form Type 3: CLIENTE */}
          {type === "cliente" && (
            <>
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-sans">RUT Titular *</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej. 12.345.678-9 o Pasaporte"
                  value={formFields.rut || ""}
                  onChange={(e) => handleInputChange("rut", e.target.value)}
                  className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Nombre Completo del Cliente *</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej. María González O."
                  value={formFields.name || ""}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Teléfono Móvil *</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Ej. +56 9 8765 4321"
                    value={formFields.phone || ""}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Correo Electrónico *</label>
                  <input 
                    type="email" 
                    required
                    placeholder="Ej. m.gonzalez@empresa.cl"
                    value={formFields.email || ""}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1.5 p-3 bg-slate-50 border border-slate-100 rounded-lg">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-sans mb-1">Vehículo Asociado Principal</label>
                <input 
                  type="text" 
                  placeholder="Ej. Ford Ranger 2019 (WX-YZ-98)"
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val) {
                      handleInputChange("vehiclesList", [val]);
                      handleInputChange("vehiclesCount", 1);
                    }
                  }}
                  className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-sans"
                />
                <span className="text-[10px] text-slate-400 mt-1 italic font-sans leading-relaxed">Formato: Marca Modelo Año (PATENTE)</span>
              </div>
            </>
          )}

          {/* Form Type 4: EMITIR FACTURA */}
          {type === "factura" && (
            <>
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Razón Social o Cliente *</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej. Transportes del Sur S.A."
                  value={formFields.clientName || ""}
                  onChange={(e) => handleInputChange("clientName", e.target.value)}
                  className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Fecha Emisión</label>
                  <input 
                    type="text" 
                    value={formFields.dateEmitted || "21 Jun 2026"}
                    onChange={(e) => handleInputChange("dateEmitted", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Vencimiento Cobros</label>
                  <input 
                    type="text" 
                    value={formFields.dueDate || "21 Jul 2026"}
                    onChange={(e) => handleInputChange("dueDate", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Monto Bruto ($ CLP) *</label>
                  <input 
                    type="number" 
                    required
                    min={100}
                    value={formFields.amount || ""}
                    onChange={(e) => handleInputChange("amount", parseInt(e.target.value) || 0)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Estado Fiscal</label>
                  <select
                    value={formFields.status || InvoiceStatus.PENDIENTE}
                    onChange={(e) => handleInputChange("status", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  >
                    <option value={InvoiceStatus.PAGADA}>PAGADA</option>
                    <option value={InvoiceStatus.PENDIENTE}>PENDIENTE</option>
                    <option value={InvoiceStatus.VENCIDA}>VENCIDA</option>
                  </select>
                </div>
              </div>
            </>
          )}

          {/* Form Type 5: NUEVO USUARIO / EMPLEADO */}
          {type === "usuario" && (
            <>
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Nombre Completo *</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej. Carlos Mendoza"
                  value={formFields.name || ""}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Rol / Cargo</label>
                  <select
                    value={formFields.role || "Mecánico Especialista"}
                    onChange={(e) => handleInputChange("role", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  >
                    <option value="Mecánico Jefe">Mecánico Jefe</option>
                    <option value="Mecánico Especialista">Mecánico Especialista</option>
                    <option value="Mecánico Junior">Mecánico Junior</option>
                    <option value="Recepcionista">Recepcionista</option>
                    <option value="Administrador">Administrador</option>
                  </select>
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Estado de Acceso</label>
                  <select
                    value={formFields.status || "ACTIVO"}
                    onChange={(e) => handleInputChange("status", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  >
                    <option value="ACTIVO">ACTIVO (Permite el ingreso)</option>
                    <option value="INACTIVO">INACTIVO (Bloquea accesos)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Correo Electrónico *</label>
                  <input 
                    type="email" 
                    required
                    placeholder="carlos.m@phtm.com"
                    value={formFields.email || ""}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Número de Teléfono *</label>
                  <input 
                    type="text" 
                    required
                    placeholder="+56 9 6000 1234"
                    value={formFields.phone || ""}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="h-10 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono"
                  />
                </div>
              </div>
            </>
          )}

          {/* Modal Buttons Footer */}
          <div className="mt-4 pt-4 border-t border-slate-100 flex gap-3 justify-end items-center">
            <button
              id="btn-modal-cancel"
              type="button"
              onClick={onClose}
              className="px-4 h-10 bg-white hover:bg-slate-55 text-slate-700 font-semibold text-xs border border-slate-200 rounded-lg shadow-sm transition-colors whitespace-nowrap select-none cursor-pointer"
            >
              Cancelar
            </button>
            <button
              id="btn-modal-save"
              type="submit"
              className="px-4 h-10 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg shadow-sm transition-colors whitespace-nowrap flex items-center justify-center gap-1.5 select-none cursor-pointer"
            >
              <Save size={14} />
              {isEdit ? "Guardar Cambios" : "Confirmar e Insertar"}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}
