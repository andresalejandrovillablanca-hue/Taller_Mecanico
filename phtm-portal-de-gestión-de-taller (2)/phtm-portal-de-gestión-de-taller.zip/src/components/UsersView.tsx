import React, { useState, useMemo } from "react";
import { Plus, Users, UserCheck, Shield, Edit3, UserCheck2, UserX, SlidersHorizontal, ChevronLeft, ChevronRight, UserCog } from "lucide-react";
import { WorkshopUser } from "../types";

interface UsersViewProps {
  users: WorkshopUser[];
  searchText: string;
  onOpenModal: () => void;
  onToggleStatus: (userId: string) => void;
  onEditUser: (user: WorkshopUser) => void;
  onDeleteUser: (userId: string) => void;
}

export default function UsersView({
  users,
  searchText,
  onOpenModal,
  onToggleStatus,
  onEditUser,
  onDeleteUser
}: UsersViewProps) {
  const [selectedRole, setSelectedRole] = useState("Todos los Roles");
  const [selectedStatus, setSelectedStatus] = useState("Todos");

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Real-time aggregates
  const stats = useMemo(() => {
    const total = users.length;
    const mechanicsCount = users.filter(u => u.role.toLowerCase().includes("mecánico") && u.status === "ACTIVO").length;
    const receptionistsCount = users.filter(u => u.role.toLowerCase().includes("recepcionista") && u.status === "ACTIVO").length;
    return {
      total,
      activeMechanics: mechanicsCount,
      activeReceptionists: receptionistsCount
    };
  }, [users]);

  // Aggregate available roles from active database 
  const rolesList = useMemo(() => {
    const list = new Set(users.map(u => u.role));
    return ["Todos los Roles", ...Array.from(list)];
  }, [users]);

  // General Filter listings
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      // Input keywords matching
      const matchesSearch = 
        u.name.toLowerCase().includes(searchText.toLowerCase()) ||
        u.id.toLowerCase().includes(searchText.toLowerCase()) ||
        u.email.toLowerCase().includes(searchText.toLowerCase()) ||
        u.role.toLowerCase().includes(searchText.toLowerCase());

      // Role filter selection
      let matchesRole = true;
      if (selectedRole !== "Todos los Roles") {
        matchesRole = u.role === selectedRole;
      }

      // Status filter selection
      let matchesStatus = true;
      if (selectedStatus === "Activo") {
        matchesStatus = u.status === "ACTIVO";
      } else if (selectedStatus === "Inactivo") {
        matchesStatus = u.status === "INACTIVO";
      }

      return matchesSearch && matchesRole && matchesStatus;
    });
  }, [users, searchText, selectedRole, selectedStatus]);

  // Background colors helper
  const getAvatarBg = (role: string) => {
    if (role.includes("Jefe")) return "bg-blue-50 text-blue-650 border border-blue-105";
    if (role.includes("Recepcion")) return "bg-indigo-50 text-indigo-650 border border-indigo-105";
    if (role.toLowerCase().includes("especialista") || role.toLowerCase().includes("técnico")) return "bg-emerald-50 text-emerald-650 border border-emerald-110";
    return "bg-slate-50 text-slate-600 border border-slate-200";
  };

  // Pagination bounds
  const totalPages = Math.max(1, Math.ceil(filteredUsers.length / itemsPerPage));
  const currentItems = useMemo(() => {
    const startIdx = (currentPage - 1) * itemsPerPage;
    return filteredUsers.slice(startIdx, startIdx + itemsPerPage);
  }, [filteredUsers, currentPage]);

  const handlePrevPage = () => setCurrentPage(p => Math.max(1, p - 1));
  const handleNextPage = () => setCurrentPage(p => Math.min(totalPages, p + 1));

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto py-2">
      
      {/* Page Header section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans">Gestión de Usuarios</h1>
          <p className="text-sm text-slate-500 mt-1">Administra los accesos del sistema, edita fichas y asigna roles a mecánicos, técnicos y recepcionistas.</p>
        </div>
        <button 
          onClick={onOpenModal}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 h-10 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg shadow-sm transition-colors whitespace-nowrap select-none cursor-pointer"
        >
          <Plus size={15} className="stroke-[2.5]" />
          Nuevo Usuario
        </button>
      </div>

      {/* Summary numeric counts row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Stat 1 */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">Total Empleados</span>
            <span className="text-blue-600 bg-blue-50 p-1.5 rounded-full"><Users size={16} /></span>
          </div>
          <div className="text-3xl font-bold text-slate-800">{stats.total || 24}</div>
        </div>

        {/* Stat 2 */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">Mecánicos Activos</span>
            <span className="text-emerald-650 bg-emerald-50 p-1.5 rounded-full"><UserCheck2 size={16} /></span>
          </div>
          <div className="text-3xl font-bold text-slate-800">{stats.activeMechanics || 18}</div>
        </div>

        {/* Stat 3 */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">Recepcionistas Activos</span>
            <span className="text-indigo-600 bg-indigo-50 p-1.5 rounded-full"><UserCog size={16} /></span>
          </div>
          <div className="text-3xl font-bold text-slate-800">{stats.activeReceptionists || 4}</div>
        </div>

      </div>

      {/* Main Listings body section */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col">
        
        {/* Toolbar selectors */}
        <div className="p-4 border-b border-[#E2E8F0] flex flex-col sm:flex-row gap-3 justify-between items-center bg-slate-50/50">
          <div className="flex gap-2 w-full sm:w-auto">
            <select
              value={selectedRole}
              onChange={(e) => { setSelectedRole(e.target.value); setCurrentPage(1); }}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all animate-none"
            >
              {rolesList.map((role, idx) => (
                <option key={idx} value={role}>{role}</option>
              ))}
            </select>
            
            <select
              value={selectedStatus}
              onChange={(e) => { setSelectedStatus(e.target.value); setCurrentPage(1); }}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-semibold focus:ring-2 focus:ring-blue-500 outline-none transition-all animate-none"
            >
              <option value="Todos">Todos los Estados</option>
              <option value="Activo">Solo Activos</option>
              <option value="Inactivo">Solo Inactivos</option>
            </select>
          </div>
          
          <button 
            onClick={() => alert("Los permisos generales del sistema pueden ser administrados en el panel de configuración central.")}
            className="text-xs font-semibold text-slate-400 hover:text-blue-600 flex items-center gap-1.5 cursor-pointer"
          >
            <SlidersHorizontal size={14} />
            Configuraciones de Seguridad
          </button>
        </div>

        {/* Staff Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Usuario</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Rol</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Email / Teléfono</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Estado (Clic para alternar)</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm text-slate-800">
              {currentItems.map((u) => {
                const isAct = u.status === "ACTIVO";
                const initials = u.name.split(" ").map(n => n[0]).join("").slice(0, 2);

                return (
                  <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                    
                    {/* User name & ID */}
                    <td className="p-4 align-middle">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${getAvatarBg(u.role)} shadow-sm select-none`}>
                          {initials}
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 leading-none">{u.name}</p>
                          <p className="font-mono text-[11px] text-slate-400 mt-1 select-all">ID: {u.id}</p>
                        </div>
                      </div>
                    </td>

                    {/* Role descriptor */}
                    <td className="p-4 align-middle font-semibold text-slate-600">
                      <span className="flex items-center gap-1.5 text-xs text-slate-705">
                        <Shield size={14} className="text-blue-650" />
                        {u.role}
                      </span>
                    </td>

                    {/* Email and mobile details */}
                    <td className="p-4 align-top text-slate-650">
                      <p className="font-semibold text-xs leading-none">{u.email}</p>
                      <p className="text-slate-400 text-xs mt-1.5 break-all font-mono">{u.phone}</p>
                    </td>

                    {/* State switch (click triggers toggling) */}
                    <td className="p-4 align-middle">
                      <button
                        onClick={() => onToggleStatus(u.id)}
                        className={`inline-flex items-center px-3 py-1 rounded-md text-[9px] font-bold uppercase tracking-wider border transition-all hover:scale-95 cursor-pointer ${
                          isAct 
                            ? "bg-emerald-50 text-emerald-700 border-emerald-105" 
                            : "bg-slate-50 text-slate-500 border border-slate-200"
                        }`}
                        title="Haz clic para activar o desactivar credenciales de acceso"
                      >
                        {u.status}
                      </button>
                    </td>

                    {/* Action trigger links */}
                    <td className="p-4 align-middle text-right">
                      <div className="flex justify-end gap-1.5">
                        <button 
                          onClick={() => onEditUser(u)}
                          className="text-slate-400 hover:text-blue-600 p-1.5 rounded-lg hover:bg-slate-55 transition-colors cursor-pointer"
                          title="Editar Ficha"
                        >
                          <Edit3 size={15} />
                        </button>
                        <button 
                          onClick={() => {
                            if (confirm(`¿Estás seguro de que deseas eliminar permanentemente al usuario ${u.name}?`)) {
                              onDeleteUser(u.id);
                            }
                          }}
                          className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50/55 transition-colors cursor-pointer"
                          title="Eliminar del Sistema"
                        >
                          {isAct ? <UserX size={15} /> : <UserCheck size={15} />}
                        </button>
                      </div>
                    </td>

                  </tr>
                );
              })}
              {currentItems.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-400 italic">
                    Sin personal administrativo o técnico para los filtros seleccionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/45 flex items-center justify-between text-xs text-slate-400 select-none">
          <span>
            Mostrando {filteredUsers.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} a {Math.min(currentPage * itemsPerPage, filteredUsers.length)} de {filteredUsers.length} registros
          </span>
          <div className="flex items-center gap-1.5">
            <button 
              onClick={handlePrevPage}
              disabled={currentPage === 1}
              className="p-1 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 disabled:opacity-40 transition-all cursor-pointer"
            >
              <ChevronLeft size={16} />
            </button>
            {Array.from({ length: totalPages }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentPage(idx + 1)}
                className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs font-semibold border cursor-pointer ${
                  currentPage === idx + 1
                    ? "bg-blue-600 text-white border-blue-600"
                    : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                }`}
              >
                {idx + 1}
              </button>
            ))}
            <button 
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className="p-1 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 disabled:opacity-40 transition-all cursor-pointer"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
