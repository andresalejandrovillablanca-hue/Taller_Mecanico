import React, { useMemo } from "react";
import { 
  BarChart3, 
  TrendingUp, 
  Wrench, 
  CheckCircle2, 
  DollarSign, 
  Package, 
  Award,
  Calendar
} from "lucide-react";
import { WorkOrder, InventoryItem, Invoice, InvoiceStatus, WorkOrderStatus } from "../types";

interface ReportesViewProps {
  orders: WorkOrder[];
  inventory: InventoryItem[];
  invoices: Invoice[];
}

export default function ReportesView({ orders, inventory, invoices }: ReportesViewProps) {
  
  // High value statistics compiled on the fly
  const summary = useMemo(() => {
    const totalJobs = orders.length;
    const completedJobs = orders.filter(o => o.status === WorkOrderStatus.COMPLETADO).length;
    const completionRate = totalJobs > 0 ? Math.round((completedJobs / totalJobs) * 100) : 100;

    const totalRevenue = invoices
      .filter(i => i.status === InvoiceStatus.PAGADA)
      .reduce((sum, curr) => sum + curr.amount, 0);

    const pendingRevenue = invoices
      .filter(i => i.status === InvoiceStatus.PENDIENTE)
      .reduce((sum, curr) => sum + curr.amount, 0);

    const lowStockItems = inventory.filter(item => item.stockActual <= item.stockMinimo).length;

    return {
      completionRate,
      completedJobs,
      totalRevenue,
      pendingRevenue,
      lowStockItems
    };
  }, [orders, inventory, invoices]);

  const formatMoney = (val: number) => {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto py-2">
      
      {/* Title Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans">Reportes Analíticos</h1>
        <p className="text-sm text-slate-500 mt-1">Gráficos de rendimiento comercial, productividad técnica y control del catálogo del taller.</p>
      </div>

      {/* Bento Grid Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* Performance Widget */}
        <div className="bg-white border border-slate-200 p-6 rounded-xl flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-sans">Efectividad Operativa</h3>
              <CheckCircle2 className="text-blue-600" size={16} />
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-bold text-slate-800">{summary.completionRate}%</span>
              <span className="text-xs text-emerald-600 font-semibold flex items-center">
                <TrendingUp size={12} className="mr-0.5" />
                Excelente
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-2 font-sans leading-relaxed">
              De las órdenes asignadas, {summary.completedJobs} reparaciones se encuentran completamente terminadas y entregadas a sus propietarios.
            </p>
          </div>

          <div className="w-full bg-slate-100 h-2 rounded-full mt-4 overflow-hidden">
            <div 
              className="bg-blue-600 h-full rounded-full" 
              style={{ width: `${summary.completionRate}%` }}
            ></div>
          </div>
        </div>

        {/* Revenue Widget */}
        <div className="bg-white border border-slate-200 p-6 rounded-xl flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-sans">Recaudación Emitida</h3>
              <DollarSign className="text-emerald-600" size={16} />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold text-slate-800 truncate">{formatMoney(summary.totalRevenue)}</span>
              <span className="text-xs text-slate-400 font-medium mt-1">Cobros percibidos este mes fiscal</span>
            </div>
            <p className="text-xs text-slate-400 mt-3 font-sans leading-relaxed">
              Monto pendiente por percibir en carteras por vencer: <strong className="text-slate-700 font-semibold">{formatMoney(summary.pendingRevenue)}</strong>.
            </p>
          </div>

          <div className="flex gap-2.5 mt-4">
            <div className="flex-1 bg-emerald-50/50 p-2 text-center rounded-lg border border-emerald-100">
              <span className="block text-[9px] uppercase text-emerald-700 font-bold tracking-wider">Percibido</span>
              <span className="text-xs font-bold text-emerald-600 font-mono">92%</span>
            </div>
            <div className="flex-1 bg-amber-50/50 p-2 text-center rounded-lg border border-amber-100">
              <span className="block text-[9px] uppercase text-amber-750 font-bold tracking-wider">En Cartera</span>
              <span className="text-xs font-bold text-amber-650 font-mono">8%</span>
            </div>
          </div>
        </div>

        {/* Catalog Health Widget */}
        <div className="bg-white border border-slate-200 p-6 rounded-xl flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-sans">Estatus del Catálogo</h3>
              <Package className="text-amber-500" size={16} />
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-bold text-slate-800">{summary.lowStockItems}</span>
              <span className="text-xs text-slate-400">artículos con stock bajo</span>
            </div>
            <p className="text-xs text-slate-400 mt-2 font-sans leading-relaxed">
              Es necesario emitir órdenes de compra de reabastecimiento para regular los niveles operantes mínimos definidos.
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-100 p-2.5 px-4 rounded-lg mt-4 text-xs font-sans font-semibold text-slate-650 flex items-center justify-between">
            <span>Reposiciones Óptimas</span>
            <span className="text-blue-600 font-mono font-bold">94.2%</span>
          </div>
        </div>

      </div>

      {/* Corporate Chart Performance Layout */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
        <h3 className="text-base font-bold text-slate-850 tracking-tight mb-4">Eficiencia Técnica de Mecánicos</h3>
        
        <div className="flex flex-col gap-4">
          
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between text-xs font-semibold text-slate-700">
              <span>John Doe (Mecánico Especialista - Suspensión)</span>
              <span className="font-mono text-slate-550">5 Ordenes Completas / 100%</span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div className="bg-blue-600 h-full rounded-full" style={{ width: "100%" }}></div>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between text-xs font-semibold text-slate-700">
              <span>Alice Smith (Mecánica Especialista - Transmisiones)</span>
              <span className="font-mono text-slate-550">4 Ordenes Completas / 85%</span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div className="bg-blue-500 h-full rounded-full" style={{ width: "85%" }}></div>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between text-xs font-semibold text-slate-700">
              <span>Robert Brown (Mecánico Junior - Mantenciones)</span>
              <span className="font-mono text-slate-550">3 Ordenes Completas / 70%</span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div className="bg-cyan-500 h-full rounded-full" style={{ width: "70%" }}></div>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
}
