import React, { useState, useMemo } from "react";
import { 
  Plus, 
  Download, 
  TrendingUp, 
  AlertTriangle, 
  Truck, 
  Search, 
  Edit3, 
  History, 
  ChevronRight,
  PlusCircle,
  MinusCircle
} from "lucide-react";
import { InventoryItem, InventoryStatus } from "../types";

interface InventoryViewProps {
  inventory: InventoryItem[];
  searchText: string;
  onOpenModal: () => void;
  onUpdateStock: (itemId: string, newQty: number) => void;
  onEditItem: (item: InventoryItem) => void;
}

export default function InventoryView({
  inventory,
  searchText,
  onOpenModal,
  onUpdateStock,
  onEditItem
}: InventoryViewProps) {
  const [selectedCategory, setSelectedCategory] = useState("Todas las Categorías");
  const [selectedStatus, setSelectedStatus] = useState("Cualquier Estado");

  // Dynamic calculations based on current list state
  const totalStockValue = useMemo(() => {
    return inventory.reduce((acc, curr) => acc + (curr.stockActual * curr.priceUnit), 0);
  }, [inventory]);

  const lowStockCount = useMemo(() => {
    return inventory.filter(item => item.stockActual <= item.stockMinimo).length;
  }, [inventory]);

  // Aggregate available categories in mock inventory
  const categoriesList = useMemo(() => {
    const list = new Set(inventory.map(i => i.category));
    return ["Todas las Categorías", ...Array.from(list)];
  }, [inventory]);

  // Filter dynamic list based on controls & search query
  const filteredInventory = useMemo(() => {
    return inventory.filter((item) => {
      // Search matches
      const matchesSearch = 
        item.name.toLowerCase().includes(searchText.toLowerCase()) ||
        item.sku.toLowerCase().includes(searchText.toLowerCase()) ||
        item.category.toLowerCase().includes(searchText.toLowerCase());

      // Category matches
      const matchesCategory = 
        selectedCategory === "Todas las Categorías" || 
        item.category === selectedCategory;

      // Status matches
      let matchesStatus = true;
      if (selectedStatus === "En Stock") {
        matchesStatus = item.stockActual > item.stockMinimo;
      } else if (selectedStatus === "Stock Bajo") {
        matchesStatus = item.stockActual > 0 && item.stockActual <= item.stockMinimo;
      } else if (selectedStatus === "Agotado") {
        matchesStatus = item.stockActual === 0;
      }

      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [inventory, searchText, selectedCategory, selectedStatus]);

  // Pricing format utilities
  const formatMoney = (val: number) => {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
      maximumFractionDigits: 0
    }).format(val || 0);
  };

  const exportData = () => {
    const content = inventory.map(item => `${item.sku},${item.name},${item.category},${item.stockActual},${item.priceUnit}`).join("\n");
    const blob = new Blob([`SKU,Nombre,Categoría,Stock,Precio\n` + content], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "PHTM-Inventario-Repuestos.csv";
    link.click();
    URL.revokeObjectURL(url);
    alert("Planilla de inventario exportada de manera correcta en formato CSV.");
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto py-2">
      
      {/* Header section with page title and actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans">Gestión de Inventario</h1>
          <p className="text-sm text-slate-500 mt-1">Monitoreo en tiempo real de stock, precios y alertas de repuestos críticos.</p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto self-stretch sm:self-auto">
          <button 
            onClick={exportData}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 h-10 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-sm border border-slate-200 rounded-lg shadow-sm transition-colors whitespace-nowrap select-none cursor-pointer"
          >
            <Download size={15} />
            Exportar
          </button>
          <button 
            onClick={onOpenModal}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 h-10 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg shadow-sm transition-colors whitespace-nowrap select-none cursor-pointer"
          >
            <Plus size={15} className="stroke-[2.5]" />
            Añadir Repuesto
          </button>
        </div>
      </div>

      {/* Summary numeric counters grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Counter Card 1: Valor total del stock */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between shadow-sm">
          <div className="flex justify-between items-start mb-3">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">Valor Total del Stock</span>
            <span className="text-emerald-600 bg-emerald-50 p-2 rounded-lg">
              <TrendingUp size={16} />
            </span>
          </div>
          <span className="text-2xl font-bold text-slate-800">{formatMoney(totalStockValue)}</span>
          <span className="text-[11px] text-emerald-600 font-semibold mt-2.5 flex items-center">
            <TrendingUp size={12} className="mr-1" />
            +2.4% este mes
          </span>
        </div>

        {/* Counter Card 2: Alertas de Stock Bajo (Warning yellow highlighting) */}
        <div className={`p-5 rounded-xl flex flex-col justify-between relative overflow-hidden transition-colors border shadow-sm ${
          lowStockCount > 0 
            ? "bg-amber-50/60 border-amber-200" 
            : "bg-white border-slate-200"
        }`}>
          <div className="absolute right-0 top-0 w-24 h-24 bg-amber-400/5 rounded-bl-full opacity-60"></div>
          <div className="flex justify-between items-start mb-3 relative z-10">
            <span className={`text-[11px] font-bold uppercase tracking-wider font-sans ${lowStockCount > 0 ? "text-amber-800" : "text-slate-500"}`}>Alertas de Stock Bajo</span>
            <span className={`p-1.5 rounded-lg ${lowStockCount > 0 ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-500"}`}>
              <AlertTriangle size={16} />
            </span>
          </div>
          <span className="text-3xl font-bold text-slate-800 relative z-10">{lowStockCount}</span>
          <span className={`text-[11px] mt-2.5 relative z-10 font-bold ${lowStockCount > 0 ? "text-amber-800" : "text-slate-400"}`}>
            {lowStockCount > 0 ? "Requieren atención inmediata" : "Suministros al día"}
          </span>
        </div>

        {/* Counter Card 3: Pedidos en tránsito */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between shadow-sm">
          <div className="flex justify-between items-start mb-3">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-sans">Pedidos en Camino</span>
            <span className="text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-100">
              <Truck size={16} />
            </span>
          </div>
          <span className="text-2xl font-bold text-slate-800">8</span>
          <span className="text-[11px] text-slate-400 font-medium mt-2.5">
            Llegada estimada en 48hs
          </span>
        </div>

      </div>

      {/* Main Parts list table section with dynamic sorting and filters */}
      <div className="bg-white border border-slate-200 rounded-xl flex flex-col overflow-hidden shadow-sm">
        
        {/* Table Filters Toolbar */}
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row gap-3 justify-between items-center bg-slate-50/45">
          <div className="flex gap-2.5 w-full sm:w-auto">
            <select 
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            >
              {categoriesList.map((cat, idx) => (
                <option key={idx} value={cat}>{cat}</option>
              ))}
            </select>
            <select 
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            >
              <option value="Cualquier Estado">Cualquier Estado</option>
              <option value="En Stock">En Stock</option>
              <option value="Stock Bajo">Stock Bajo</option>
              <option value="Agotado">Agotado</option>
            </select>
          </div>
          <span className="text-xs font-semibold text-slate-400">
            Mostrando {filteredInventory.length} de {inventory.length} repuestos
          </span>
        </div>

        {/* Responsive Parts table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Repuesto / SKU</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Categoría</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center">Stock Actual</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-right">Stock Mín.</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-right">Precio Unit.</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Estado</th>
                <th className="p-4 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm text-slate-800">
              {filteredInventory.map((item) => {
                const isLow = item.stockActual <= item.stockMinimo;
                const isOut = item.stockActual === 0;

                return (
                  <tr 
                    key={item.id} 
                    className={`hover:bg-slate-50/50 transition-colors ${isOut ? "bg-rose-50/10" : ""}`}
                  >
                    <td className="p-4 align-top">
                      <div className="font-bold text-slate-800">{item.name}</div>
                      <div className="font-mono text-[11px] text-slate-400 mt-1 select-all">{item.sku}</div>
                      {item.notes && (
                        <p className="text-[11px] text-slate-400 italic mt-1 font-sans">{item.notes}</p>
                      )}
                    </td>
                    <td className="p-4 align-middle font-semibold text-slate-500">
                      {item.category}
                    </td>
                    <td className="p-4 align-middle text-center">
                      <div className="flex items-center justify-center gap-2.5">
                        {/* Inline Decrement stock controls */}
                        <button 
                          onClick={() => onUpdateStock(item.id, Math.max(0, item.stockActual - 1))}
                          className="text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                          title="Disminuir -1"
                        >
                          <MinusCircle size={16} />
                        </button>
                        <span className={`font-mono font-bold text-base w-7 ${
                          isOut ? "text-rose-650" : isLow ? "text-amber-500" : "text-slate-800"
                        }`}>
                          {item.stockActual}
                        </span>
                        {/* Inline Increment stock controls */}
                        <button 
                          onClick={() => onUpdateStock(item.id, item.stockActual + 1)}
                          className="text-slate-400 hover:text-blue-600 transition-colors cursor-pointer"
                          title="Aumentar +1"
                        >
                          <PlusCircle size={16} />
                        </button>
                      </div>
                    </td>
                    <td className="p-4 align-middle text-right font-mono text-slate-400">
                      {item.stockMinimo}
                    </td>
                    <td className="p-4 align-middle text-right font-mono font-bold text-slate-800">
                      {formatMoney(item.priceUnit)}
                    </td>
                    <td className="p-4 align-middle">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider ${
                        isOut 
                          ? "bg-rose-50 text-rose-700 border border-rose-100" 
                          : isLow 
                          ? "bg-amber-50 text-amber-700 border border-amber-100" 
                          : "bg-blue-50 text-blue-700 border border-blue-100"
                      }`}>
                        {isOut ? "AGOTADO" : isLow ? "STOCK BAJO" : "EN STOCK"}
                      </span>
                    </td>
                    <td className="p-4 align-middle text-right">
                      <div className="flex justify-end gap-1">
                        <button 
                          onClick={() => onEditItem(item)}
                          className="text-slate-400 hover:text-blue-600 p-1.5 rounded-lg hover:bg-slate-55 transition-all cursor-pointer"
                          title="Editar Repuesto"
                        >
                          <Edit3 size={15} />
                        </button>
                        <button 
                          onClick={() => alert(`Historial del repuesto ${item.sku} - Stock cargado y auditado por Andrés Villablanca.`)}
                          className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-55 transition-all cursor-pointer"
                          title="Ver Historial"
                        >
                          <History size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredInventory.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400 font-sans italic">
                    No se encontraron repuestos con los criterios de búsqueda actuales.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Extra Bottom Caution Alert Banner */}
        {lowStockCount > 0 && (
          <div className="bg-amber-50/80 border-t border-amber-100 p-3.5 px-5 flex items-center gap-3 text-xs text-amber-850 font-semibold">
            <AlertTriangle size={15} className="text-amber-500" />
            <span>Atención: Se encuentran {lowStockCount} insumos por debajo del límite de reorden establecido. Revisa la lista resaltada con etiquetas de advertencia.</span>
          </div>
        )}

      </div>

    </div>
  );
}
