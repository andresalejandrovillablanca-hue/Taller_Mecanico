export enum WorkOrderStatus {
  EN_CURSO = "EN CURSO",
  PENDIENTE_DE_REPUESTOS = "PENDIENTE DE REPUESTOS",
  COMPLETADO = "COMPLETADO"
}

export interface WorkOrder {
  id: string; // e.g. "WO-2049"
  clientName: string;
  clientId: string; // reference to customer
  vehicleInfo: string; // e.g. "2021 Ford Transit 250"
  plateNumber: string; // e.g. "XYZ-9876"
  technicianName: string; // e.g. "Mike R."
  status: WorkOrderStatus;
  estimatedDelivery: string; // e.g. "Oct 24, 14:00" or "Por definir"
  notes?: string;
  createdAt: string; // e.g. "hace 10 min" or actual date
}

export enum InventoryStatus {
  EN_STOCK = "EN STOCK",
  STOCK_BAJO = "STOCK BAJO",
  AGOTADO = "AGOTADO"
}

export interface InventoryItem {
  id: string; // e.g. "FLT-001-X7"
  name: string;
  category: string; // e.g. "Filtros"
  stockActual: number;
  stockMinimo: number;
  priceUnit: number;
  status: InventoryStatus;
  sku: string;
  notes?: string;
}

export interface Customer {
  id: string; // e.g. "CUST-1"
  name: string;
  rut: string; // Chilean National ID, e.g. "12.345.678-9"
  phone: string; // e.g. "+56 9 1234 5678"
  email: string;
  vehiclesCount: number;
  vehiclesList: string[]; // e.g. ["Toyota Hilux 2021 (AB-CD-12)"]
  lastVisit: string; // e.g. "12 Oct, 2023"
}

export enum InvoiceStatus {
  PAGADA = "PAGADA",
  PENDIENTE = "PENDIENTE",
  VENCIDA = "VENCIDA"
}

export interface Invoice {
  id: string; // e.g. "FAC-2023-1042"
  clientName: string;
  dateEmitted: string; // e.g. "24 Oct 2023"
  amount: number;
  status: InvoiceStatus;
  dueDate: string;
}

export interface WorkshopUser {
  id: string; // e.g. "TLL-042"
  name: string;
  role: string; // e.g. "Mecánico Jefe", "Recepcionista", "Mecánico Especialista"
  email: string;
  phone: string;
  status: "ACTIVO" | "INACTIVO";
}

export interface DashboardStats {
  activeOrdersCount: number;
  lowStockAlertsCount: number;
  monthlyRevenue: number;
  pendingApprovalsCount: number;
  totalCustomers: number;
  activeStaffCount: number;
}
